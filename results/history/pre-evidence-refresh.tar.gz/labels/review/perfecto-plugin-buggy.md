# Labelling pack: perfecto-plugin / buggy

4 rows to label. Write TP or FP (+ code and reason in `notes`) in `labels/perfecto-plugin-buggy.csv`, row = `flow_id`. Rule: docs/labelling-guide.md.

---

## 1/4 flow_id 05a565b1c4 (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow 05a565b1c4
key        : DRIVER => <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>@L167/0[*]
source     : <nesy.NesyDriver: void main(java.lang.String[])>[56@L19] %v37 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[104@L167] process = invokevirtual %v93.exec(cmdArgs#1)/0[*]
fixed methods on this flow (GT): PerfectoBuildWrapper.getTunnelId, PerfectoBuildWrapper.PerfectoBuildWrapper
reported by: B2 run0, v4 run1, v4 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[83@L24] %v53 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v53}
3. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>/perfectoConnectLocation}
4. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String perfectoConnectLocation>}
5. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>/%v26}
6. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/perfectoConnectLocation}
7. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v82}
8. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v83}
9. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v85}
10. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v86}
11. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v90}
12. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v91}
13. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v92}
14. ArrayIndexNode{NewObj{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[81@L166] newarray java.lang.String[%ci3]}}
15. <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[104@L167] process = invokevirtual %v93.exec(cmdArgs#1)/0[*]

## Code of the application methods on the route
### <io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  280 | 	}
  281 | 
  282 | 	public void setPerfectoConnectLocation(String perfectoConnectLocation) {
  283 | 		this.perfectoConnectLocation = perfectoConnectLocation;
  284 | 	}
  285 | 
  286 | 	public String getSecurityToken() {
  287 | 		return perfectoSecurityToken;

### <io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  203 | 	 */
  204 | 	@Override
  205 | 	public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener) throws IOException, InterruptedException {
  206 | 		listener.getLogger().println("Creating Tunnel Id........!");
  207 | 		logger.fine("Setting Perfecto Build Wrapper");
  208 | 
  209 | 		credentials = PerfectoCredentials.getPerfectoCredentials(build, this);
  210 | 		CredentialsProvider.track(build, credentials);
  211 | 
  212 | 		if(credentials==null && !reuseTunnelId.contains("-")) {
  213 | 			listener.fatalError("Credentials missing......");
  214 | 			throw new IOException("Credentials missing......");
  215 | 		}
  216 | 
  217 | 		if(!reuseTunnelId.contains("-")) {
  218 | 			final String apiKey = credentials.getPassword().getPlainText();
  219 | 			tunnelId = getTunnelId(perfectoConnectLocation, credentials.getCloudName(), apiKey, listener);
  220 | 		}
  221 | 		else
  222 | 			tunnelId = reuseTunnelId;
  223 | 		listener.getLogger().println("Tunnel Id created succesfully.");
  224 | 
  225 | 		return new Environment() {
  226 | 
  227 | 			/**
  228 | 			 * Updates the environment variable map to include the Perfecto specific environment variables applicable to the build.

### <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  149 | 	}
  150 | 
  151 | 	private String getTunnelId(String perfectoConnectLocation, String cloudName, String apiKey, BuildListener listener) throws IOException {
  152 | 		String tunnelId = null;
  153 | 		boolean isWindows = hudson.Functions.isWindows();
  154 | 		Process process;
  155 | 		if(perfectoConnectLocation.endsWith("/")||perfectoConnectLocation.endsWith("\\")) {
  156 | 			pcLocation = perfectoConnectLocation+perfectoConnectFile;
  157 | 		}else {
  158 | 			pcLocation = perfectoConnectLocation+File.separator+perfectoConnectFile;
  159 | 		}
  160 | 		String baseCommand = pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s "+apiKey.trim();
  161 | 		listener.getLogger().println(pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s <<TOKEN>> "+pcParameters.trim());
  162 | 		if (isWindows) {
  163 | 			String cmdArgs[] = {"cmd.exe", "/c", baseCommand+" "+pcParameters.trim()};
  164 | 			process = new ProcessBuilder(cmdArgs).redirectErrorStream(true).start();
  165 | 		} else {
  166 | 			String cmdArgs[] = {"bash", "-c", "(cd "+perfectoConnectLocation+"; "+baseCommand+" "+pcParameters.trim()+")"};
  167 | 			process = Runtime.getRuntime().exec(cmdArgs);
  168 | 		}
  169 | 		InputStream is = process.getInputStream();
  170 | 		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
  171 | 		String s = null;
  172 | 		while ((s = reader.readLine()) != null) {
  173 | 			listener.getLogger().println(s);
  174 | 			Matcher m = Pattern.compile("^[A-Za-z0-9-]+$").matcher(s);
  175 | 			if (m.find()) {
  176 | 				tunnelId = m.group(0);
  177 | 				listener.getLogger().println("Tunnel Id : "+tunnelId);
  178 | 			}
  179 | 			if(s.contains("bash: ")) {
  180 | 				listener.fatalError("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  181 | 				throw new IOException("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  182 | 			}
  183 | 			if(s.contains("Can't start Perfecto Connect")||s.contains("failed to start")) {
  184 | 				listener.fatalError(tunnelId);
  185 | 				throw new IOException(tunnelId);
  186 | 			}
  187 | 		}
  188 | 		reader.close();
  189 | 		if(tunnelId == null) {
  190 | 			listener.fatalError("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  191 | 			throw new IOException("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  192 | 		}
  193 | 		return tunnelId;
  194 | 	}
  195 | 
  196 | 
```

---

## 2/4 flow_id dde7ff1fc9 (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow dde7ff1fc9
key        : DRIVER => <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>@L180/0
source     : <nesy.NesyDriver: void main(java.lang.String[])>[57@L19] %v38 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[141@L180] invokeinterface listener.fatalError(%v120)/0
fixed methods on this flow (GT): PerfectoBuildWrapper.getTunnelId, PerfectoBuildWrapper.setUp, PerfectoBuildWrapper.PerfectoBuildWrapper
reported by: iris-like run0, v1 run0, v4 run0
N3 (iris-like run0): uncertain /  (kept=True, v3_ok=None)

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[83@L24] %v53 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v53}
3. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>/perfectoConnectLocation}
4. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String perfectoConnectLocation>}
5. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>/%v26}
6. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/perfectoConnectLocation}
7. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v27}
8. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v29}
9. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v30}
10. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String pcLocation>}
11. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v116}
12. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v118}
13. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v119}
14. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v120}
15. <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[141@L180] invokeinterface listener.fatalError(%v120)/0

## Code of the application methods on the route
### <io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  280 | 	}
  281 | 
  282 | 	public void setPerfectoConnectLocation(String perfectoConnectLocation) {
  283 | 		this.perfectoConnectLocation = perfectoConnectLocation;
  284 | 	}
  285 | 
  286 | 	public String getSecurityToken() {
  287 | 		return perfectoSecurityToken;

### <io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  203 | 	 */
  204 | 	@Override
  205 | 	public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener) throws IOException, InterruptedException {
  206 | 		listener.getLogger().println("Creating Tunnel Id........!");
  207 | 		logger.fine("Setting Perfecto Build Wrapper");
  208 | 
  209 | 		credentials = PerfectoCredentials.getPerfectoCredentials(build, this);
  210 | 		CredentialsProvider.track(build, credentials);
  211 | 
  212 | 		if(credentials==null && !reuseTunnelId.contains("-")) {
  213 | 			listener.fatalError("Credentials missing......");
  214 | 			throw new IOException("Credentials missing......");
  215 | 		}
  216 | 
  217 | 		if(!reuseTunnelId.contains("-")) {
  218 | 			final String apiKey = credentials.getPassword().getPlainText();
  219 | 			tunnelId = getTunnelId(perfectoConnectLocation, credentials.getCloudName(), apiKey, listener);
  220 | 		}
  221 | 		else
  222 | 			tunnelId = reuseTunnelId;
  223 | 		listener.getLogger().println("Tunnel Id created succesfully.");
  224 | 
  225 | 		return new Environment() {
  226 | 
  227 | 			/**
  228 | 			 * Updates the environment variable map to include the Perfecto specific environment variables applicable to the build.

### <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  149 | 	}
  150 | 
  151 | 	private String getTunnelId(String perfectoConnectLocation, String cloudName, String apiKey, BuildListener listener) throws IOException {
  152 | 		String tunnelId = null;
  153 | 		boolean isWindows = hudson.Functions.isWindows();
  154 | 		Process process;
  155 | 		if(perfectoConnectLocation.endsWith("/")||perfectoConnectLocation.endsWith("\\")) {
  156 | 			pcLocation = perfectoConnectLocation+perfectoConnectFile;
  157 | 		}else {
  158 | 			pcLocation = perfectoConnectLocation+File.separator+perfectoConnectFile;
  159 | 		}
  160 | 		String baseCommand = pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s "+apiKey.trim();
  161 | 		listener.getLogger().println(pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s <<TOKEN>> "+pcParameters.trim());
  162 | 		if (isWindows) {
  163 | 			String cmdArgs[] = {"cmd.exe", "/c", baseCommand+" "+pcParameters.trim()};
  164 | 			process = new ProcessBuilder(cmdArgs).redirectErrorStream(true).start();
  165 | 		} else {
  166 | 			String cmdArgs[] = {"bash", "-c", "(cd "+perfectoConnectLocation+"; "+baseCommand+" "+pcParameters.trim()+")"};
  167 | 			process = Runtime.getRuntime().exec(cmdArgs);
  168 | 		}
  169 | 		InputStream is = process.getInputStream();
  170 | 		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
  171 | 		String s = null;
  172 | 		while ((s = reader.readLine()) != null) {
  173 | 			listener.getLogger().println(s);
  174 | 			Matcher m = Pattern.compile("^[A-Za-z0-9-]+$").matcher(s);
  175 | 			if (m.find()) {
  176 | 				tunnelId = m.group(0);
  177 | 				listener.getLogger().println("Tunnel Id : "+tunnelId);
  178 | 			}
  179 | 			if(s.contains("bash: ")) {
  180 | 				listener.fatalError("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  181 | 				throw new IOException("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  182 | 			}
  183 | 			if(s.contains("Can't start Perfecto Connect")||s.contains("failed to start")) {
  184 | 				listener.fatalError(tunnelId);
  185 | 				throw new IOException(tunnelId);
  186 | 			}
  187 | 		}
  188 | 		reader.close();
  189 | 		if(tunnelId == null) {
  190 | 			listener.fatalError("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  191 | 			throw new IOException("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  192 | 		}
  193 | 		return tunnelId;
  194 | 	}
  195 | 
  196 | 
```

---

## 3/4 flow_id 21ba189d7d (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow 21ba189d7d
key        : DRIVER => <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>@L164/0[*]
source     : <nesy.NesyDriver: void main(java.lang.String[])>[56@L19] %v37 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[77@L164] invokespecial %v73.<init>(cmdArgs)/0[*]
fixed methods on this flow (GT): PerfectoBuildWrapper.getTunnelId, PerfectoBuildWrapper.PerfectoBuildWrapper
reported by: B2 run0, v4 run1, v4 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[83@L24] %v53 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v53}
3. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>/perfectoConnectLocation}
4. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String perfectoConnectLocation>}
5. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>/%v26}
6. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/perfectoConnectLocation}
7. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v27}
8. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v29}
9. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v30}
10. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String pcLocation>}
11. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v32}
12. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v33}
13. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v35}
14. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v36}
15. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v39}
16. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v40}
17. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v42}
18. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/baseCommand}
19. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v67}
20. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v68}
21. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v71}
22. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v72}
23. ArrayIndexNode{NewObj{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[61@L163] newarray java.lang.String[%ci3]}}
24. <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[77@L164] invokespecial %v73.<init>(cmdArgs)/0[*]

## Code of the application methods on the route
### <io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  280 | 	}
  281 | 
  282 | 	public void setPerfectoConnectLocation(String perfectoConnectLocation) {
  283 | 		this.perfectoConnectLocation = perfectoConnectLocation;
  284 | 	}
  285 | 
  286 | 	public String getSecurityToken() {
  287 | 		return perfectoSecurityToken;

### <io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  203 | 	 */
  204 | 	@Override
  205 | 	public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener) throws IOException, InterruptedException {
  206 | 		listener.getLogger().println("Creating Tunnel Id........!");
  207 | 		logger.fine("Setting Perfecto Build Wrapper");
  208 | 
  209 | 		credentials = PerfectoCredentials.getPerfectoCredentials(build, this);
  210 | 		CredentialsProvider.track(build, credentials);
  211 | 
  212 | 		if(credentials==null && !reuseTunnelId.contains("-")) {
  213 | 			listener.fatalError("Credentials missing......");
  214 | 			throw new IOException("Credentials missing......");
  215 | 		}
  216 | 
  217 | 		if(!reuseTunnelId.contains("-")) {
  218 | 			final String apiKey = credentials.getPassword().getPlainText();
  219 | 			tunnelId = getTunnelId(perfectoConnectLocation, credentials.getCloudName(), apiKey, listener);
  220 | 		}
  221 | 		else
  222 | 			tunnelId = reuseTunnelId;
  223 | 		listener.getLogger().println("Tunnel Id created succesfully.");
  224 | 
  225 | 		return new Environment() {
  226 | 
  227 | 			/**
  228 | 			 * Updates the environment variable map to include the Perfecto specific environment variables applicable to the build.

### <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  149 | 	}
  150 | 
  151 | 	private String getTunnelId(String perfectoConnectLocation, String cloudName, String apiKey, BuildListener listener) throws IOException {
  152 | 		String tunnelId = null;
  153 | 		boolean isWindows = hudson.Functions.isWindows();
  154 | 		Process process;
  155 | 		if(perfectoConnectLocation.endsWith("/")||perfectoConnectLocation.endsWith("\\")) {
  156 | 			pcLocation = perfectoConnectLocation+perfectoConnectFile;
  157 | 		}else {
  158 | 			pcLocation = perfectoConnectLocation+File.separator+perfectoConnectFile;
  159 | 		}
  160 | 		String baseCommand = pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s "+apiKey.trim();
  161 | 		listener.getLogger().println(pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s <<TOKEN>> "+pcParameters.trim());
  162 | 		if (isWindows) {
  163 | 			String cmdArgs[] = {"cmd.exe", "/c", baseCommand+" "+pcParameters.trim()};
  164 | 			process = new ProcessBuilder(cmdArgs).redirectErrorStream(true).start();
  165 | 		} else {
  166 | 			String cmdArgs[] = {"bash", "-c", "(cd "+perfectoConnectLocation+"; "+baseCommand+" "+pcParameters.trim()+")"};
  167 | 			process = Runtime.getRuntime().exec(cmdArgs);
  168 | 		}
  169 | 		InputStream is = process.getInputStream();
  170 | 		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
  171 | 		String s = null;
  172 | 		while ((s = reader.readLine()) != null) {
  173 | 			listener.getLogger().println(s);
  174 | 			Matcher m = Pattern.compile("^[A-Za-z0-9-]+$").matcher(s);
  175 | 			if (m.find()) {
  176 | 				tunnelId = m.group(0);
  177 | 				listener.getLogger().println("Tunnel Id : "+tunnelId);
  178 | 			}
  179 | 			if(s.contains("bash: ")) {
  180 | 				listener.fatalError("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  181 | 				throw new IOException("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  182 | 			}
  183 | 			if(s.contains("Can't start Perfecto Connect")||s.contains("failed to start")) {
  184 | 				listener.fatalError(tunnelId);
  185 | 				throw new IOException(tunnelId);
  186 | 			}
  187 | 		}
  188 | 		reader.close();
  189 | 		if(tunnelId == null) {
  190 | 			listener.fatalError("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  191 | 			throw new IOException("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  192 | 		}
  193 | 		return tunnelId;
  194 | 	}
  195 | 
  196 | 
```

---

## 4/4 flow_id 20278dfc29 (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow 20278dfc29
key        : DRIVER => <io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>@L111/0
source     : <nesy.NesyDriver: void main(java.lang.String[])>[7@L8] %v8 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>[14@L111] invokespecial myURL.<init>(checkConnectionURL)/0
fixed methods on this flow (GT): DescriptorImpl.doAuthenticate
reported by: v1 run1, v2 run1

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[126@L32] %v81 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v81}
3. VarNode{<io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>/apikey}
4. VarNode{<io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>/%v16}
5. VarNode{<io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>/checkConnectionURL}
6. <io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>[14@L111] invokespecial myURL.<init>(checkConnectionURL)/0

## Code of the application methods on the route
### <io.plugins.perfecto.credentials.PerfectoCredentials: hudson.util.FormValidation testAuthentication(java.lang.String,java.lang.String,java.lang.String)>
file: io/plugins/perfecto/credentials/PerfectoCredentials.java
  104 | 	}
  105 | 
  106 | 	public static FormValidation testAuthentication(final String username, final String cloudName, final String apikey) {
  107 | 		String checkConnectionURL = "https://"+cloudName+".perfectomobile.com/services/users/"+username+"?operation=info&securityToken="+apikey;
  108 | 		URL myURL;
  109 | 		HttpsURLConnection conn = null;
  110 | 		try {
  111 | 			myURL = new URL(checkConnectionURL);
  112 | 			conn = (HttpsURLConnection) myURL.openConnection();
  113 | 			conn.setRequestMethod("POST");
  114 | 			conn.setRequestProperty("Accept", "application/json");
  115 | 			int response = conn.getResponseCode();
  116 | 			System.out.println("response"+response);
  117 | 			if (response != 200) {
  118 | 				conn.disconnect();
  119 | 				return FormValidation.error(ERR_INVALID_AUTH+", HTTP error code : "+response);
  120 | 			}
  121 | 			conn.disconnect();
  122 | 		}catch(Exception e) {
  123 | 			if(conn != null) {
  124 | 				conn.disconnect();
  125 | 			}
  126 | 			System.out.println("exception: "+e);
  127 | 			return FormValidation.error(ERR_INVALID_AUTH);
  128 | 		}
  129 | 		System.out.println("success");
  130 | 		return FormValidation.ok(OK_VALID_AUTH);
  131 | 	}
  132 | 
  133 | 	public static PerfectoCredentials getCredentials(AbstractBuild build) {
```
