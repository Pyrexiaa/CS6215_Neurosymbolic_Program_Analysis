# Blind labelling sample (60 flows)

Label each flow TP or FP in `blind-sample.csv` (column `my_label`), following docs/labelling-guide.md. Do not open labels/*.csv until you are done.

---
# 1. spark / buggy / 16c3cf872e

## 80/113 flow_id 16c3cf872e (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 16c3cf872e
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L54/result => <spark.resource.ClassPathResource: boolean exists()>@L120/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[20@L54] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.resource.ClassPathResource: boolean exists()>[6@L120] url = invokevirtual %v4.getResource(%v5)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResource: boolean exists()>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.resource.ClassPathResource: boolean exists()>
file: spark/resource/ClassPathResource.java
  116 |     @Override
  117 |     public boolean exists() {
  118 |         URL url;
  119 |         if (this.clazz != null) {
  120 |             url = this.clazz.getResource(this.path);
  121 |         } else {
  122 |             url = this.classLoader.getResource(this.path);
  123 |         }
  124 |         return (url != null);
  125 |     }
  126 | 
  127 |     /**
```


---
# 2. spark / buggy / 8aa7fa0ac1

## 75/113 flow_id 8aa7fa0ac1 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 8aa7fa0ac1
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L51/result => <spark.resource.ClassPathResource: boolean exists()>@L122/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[18@L51] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.resource.ClassPathResource: boolean exists()>[10@L122] url = invokevirtual %v6.getResource(%v7)/0
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResource: boolean exists()>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.resource.ClassPathResource: boolean exists()>
file: spark/resource/ClassPathResource.java
  116 |     @Override
  117 |     public boolean exists() {
  118 |         URL url;
  119 |         if (this.clazz != null) {
  120 |             url = this.clazz.getResource(this.path);
  121 |         } else {
  122 |             url = this.classLoader.getResource(this.path);
  123 |         }
  124 |         return (url != null);
  125 |     }
  126 | 
  127 |     /**
```


---
# 3. perfecto-plugin / buggy / 21ba189d7d

## 3/4 flow_id 21ba189d7d (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow 21ba189d7d
key        : DRIVER => <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>@L164/0[*]
source     : <nesy.NesyDriver: void main(java.lang.String[])>[56@L19] %v37 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[77@L164] invokespecial %v73.<init>(cmdArgs)/0[*]
fixed methods on this flow (GT): PerfectoBuildWrapper.getTunnelId, PerfectoBuildWrapper.PerfectoBuildWrapper
reported by: B2 run0, v4 run1, v4 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[83@L24] %v53 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v53}
3. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>/perfectoConnectLocation}
4. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String perfectoConnectLocation>}
5. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>/%v26}
6. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/perfectoConnectLocation}
7. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v27}
8. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v29}
9. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v30}
10. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String pcLocation>}
11. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v32}
12. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v33}
13. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v35}
14. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v36}
15. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v39}
16. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v40}
17. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v42}
18. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/baseCommand}
19. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v67}
20. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v68}
21. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v71}
22. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v72}
23. ArrayIndexNode{NewObj{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[61@L163] newarray java.lang.String[%ci3]}}
24. <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[77@L164] invokespecial %v73.<init>(cmdArgs)/0[*]

## Code of the application methods on the route
### <io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  280 | 	}
  281 | 
  282 | 	public void setPerfectoConnectLocation(String perfectoConnectLocation) {
  283 | 		this.perfectoConnectLocation = perfectoConnectLocation;
  284 | 	}
  285 | 
  286 | 	public String getSecurityToken() {
  287 | 		return perfectoSecurityToken;

### <io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  203 | 	 */
  204 | 	@Override
  205 | 	public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener) throws IOException, InterruptedException {
  206 | 		listener.getLogger().println("Creating Tunnel Id........!");
  207 | 		logger.fine("Setting Perfecto Build Wrapper");
  208 | 
  209 | 		credentials = PerfectoCredentials.getPerfectoCredentials(build, this);
  210 | 		CredentialsProvider.track(build, credentials);
  211 | 
  212 | 		if(credentials==null && !reuseTunnelId.contains("-")) {
  213 | 			listener.fatalError("Credentials missing......");
  214 | 			throw new IOException("Credentials missing......");
  215 | 		}
  216 | 
  217 | 		if(!reuseTunnelId.contains("-")) {
  218 | 			final String apiKey = credentials.getPassword().getPlainText();
  219 | 			tunnelId = getTunnelId(perfectoConnectLocation, credentials.getCloudName(), apiKey, listener);
  220 | 		}
  221 | 		else
  222 | 			tunnelId = reuseTunnelId;
  223 | 		listener.getLogger().println("Tunnel Id created succesfully.");
  224 | 
  225 | 		return new Environment() {
  226 | 
  227 | 			/**
  228 | 			 * Updates the environment variable map to include the Perfecto specific environment variables applicable to the build.

### <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  149 | 	}
  150 | 
  151 | 	private String getTunnelId(String perfectoConnectLocation, String cloudName, String apiKey, BuildListener listener) throws IOException {
  152 | 		String tunnelId = null;
  153 | 		boolean isWindows = hudson.Functions.isWindows();
  154 | 		Process process;
  155 | 		if(perfectoConnectLocation.endsWith("/")||perfectoConnectLocation.endsWith("\\")) {
  156 | 			pcLocation = perfectoConnectLocation+perfectoConnectFile;
  157 | 		}else {
  158 | 			pcLocation = perfectoConnectLocation+File.separator+perfectoConnectFile;
  159 | 		}
  160 | 		String baseCommand = pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s "+apiKey.trim();
  161 | 		listener.getLogger().println(pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s <<TOKEN>> "+pcParameters.trim());
  162 | 		if (isWindows) {
  163 | 			String cmdArgs[] = {"cmd.exe", "/c", baseCommand+" "+pcParameters.trim()};
  164 | 			process = new ProcessBuilder(cmdArgs).redirectErrorStream(true).start();
  165 | 		} else {
  166 | 			String cmdArgs[] = {"bash", "-c", "(cd "+perfectoConnectLocation+"; "+baseCommand+" "+pcParameters.trim()+")"};
  167 | 			process = Runtime.getRuntime().exec(cmdArgs);
  168 | 		}
  169 | 		InputStream is = process.getInputStream();
  170 | 		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
  171 | 		String s = null;
  172 | 		while ((s = reader.readLine()) != null) {
  173 | 			listener.getLogger().println(s);
  174 | 			Matcher m = Pattern.compile("^[A-Za-z0-9-]+$").matcher(s);
  175 | 			if (m.find()) {
  176 | 				tunnelId = m.group(0);
  177 | 				listener.getLogger().println("Tunnel Id : "+tunnelId);
  178 | 			}
  179 | 			if(s.contains("bash: ")) {
  180 | 				listener.fatalError("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  181 | 				throw new IOException("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  182 | 			}
  183 | 			if(s.contains("Can't start Perfecto Connect")||s.contains("failed to start")) {
  184 | 				listener.fatalError(tunnelId);
  185 | 				throw new IOException(tunnelId);
  186 | 			}
  187 | 		}
  188 | 		reader.close();
  189 | 		if(tunnelId == null) {
  190 | 			listener.fatalError("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  191 | 			throw new IOException("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  192 | 		}
  193 | 		return tunnelId;
  194 | 	}
  195 | 
  196 | 
```


---
# 4. zt-zip / buggy / a9e98b5727

## 109/115 flow_id a9e98b5727 (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow a9e98b5727
key        : <org.apache.log4j.Hierarchy: java.util.Enumeration getCurrentLoggers()>@L313/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceMkdir(java.io.File)>@L888/0
source     : <org.apache.log4j.Hierarchy: java.util.Enumeration getCurrentLoggers()>[9@L313] o = invokeinterface elems.nextElement()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceMkdir(java.io.File)>[14@L888] invokespecial %v12.<init>(message)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceMkdir(java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceMkdir(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  878 |    * @throws IOException if the directory cannot be created or the file already exists but is not a directory
  879 |    */
  880 |   public static void forceMkdir(File directory) throws IOException {
  881 |     if (directory.exists()) {
  882 |       if (!directory.isDirectory()) {
  883 |         String message =
  884 |             "File "
  885 |                 + directory
  886 |                 + " exists and is "
  887 |                 + "not a directory. Unable to create directory.";
  888 |         throw new IOException(message);
  889 |       }
  890 |     } else {
  891 |       if (!directory.mkdirs()) {
  892 |         // Double-check that some other thread or process hasn't made
  893 |         // the directory in the background
  894 |         if (!directory.isDirectory())
  895 |         {
  896 |           String message =
  897 |               "Unable to create directory " + directory;
  898 |           throw new IOException(message);
  899 |         }
  900 |       }
  901 |     }
  902 |   }
  903 | 
  904 |   //-----------------------------------------------------------------------
  905 |   /**
```


---
# 5. spark / buggy / 4b68888eda

## 92/113 flow_id 4b68888eda (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 4b68888eda
key        : <org.eclipse.jetty.server.Response: java.lang.String getHeader(java.lang.String)>@L765/result => <spark.resource.ClassPathResource: java.net.URL getURL()>@L161/0
source     : <org.eclipse.jetty.server.Response: java.lang.String getHeader(java.lang.String)>[1@L765] %v3 = invokevirtual %v2.get(name)/result
sink       : <spark.resource.ClassPathResource: java.net.URL getURL()>[4@L161] url = invokevirtual %v4.getResource(%v5)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.ClassPathResource: java.net.URL getURL()>

## Code of the application methods on the route
### <spark.resource.ClassPathResource: java.net.URL getURL()>
file: spark/resource/ClassPathResource.java
  157 |     @Override
  158 |     public URL getURL() throws IOException {
  159 |         URL url;
  160 |         if (this.clazz != null) {
  161 |             url = this.clazz.getResource(this.path);
  162 |         } else {
  163 |             url = this.classLoader.getResource(this.path);
  164 |         }
  165 |         if (url == null) {
  166 |             throw new FileNotFoundException(getDescription() + " cannot be resolved to URL because it does not exist");
  167 |         }
  168 |         return url;
  169 |     }
  170 | 
  171 |     /**
```


---
# 6. spark / buggy / f389662b0a

## 112/113 flow_id f389662b0a (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow f389662b0a
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L54/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L222/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[20@L54] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[25@L222] invokespecial %v19.<init>(%v20)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 7. zt-zip / fixed / 971ab7d686

## 37/97 flow_id 971ab7d686 (priority 1)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 971ab7d686
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1277/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>@L623/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1277] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>[65@L623] invokespecial dstFile.<init>(destDir, %v52)/1
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1277 |       String root = getRootName(zipEntry.getName());
 1278 |       if (rootDir == null) {
 1279 |         rootDir = root;
 1280 |       }
 1281 |       else if (!rootDir.equals(root)) {
 1282 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1283 |       }
 1284 | 
 1285 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1286 |       if (name != null) {
 1287 |         File file = new File(outputDir, name);
 1288 | 
 1289 |         /* If we see the relative traversal string of ".." we need to make sure
 1290 |          * that the outputdir + name doesn't leave the outputdir. See
 1291 |          * DirectoryTraversalMaliciousTest for details.
 1292 |          */
 1293 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1294 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1295 |         }
 1296 | 
 1297 |         if (zipEntry.isDirectory()) {
 1298 |           FileUtils.forceMkdir(file);
 1299 |         }
 1300 |         else {
 1301 |           FileUtils.forceMkdir(file.getParentFile());
 1302 | 
 1303 |           if (log.isDebugEnabled() && file.exists()) {
 1304 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1305 |           }
 1306 | 
 1307 |           FileUtils.copy(in, file);
 1308 |         }
 1309 |       }
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  603 |   private static void doCopyDirectory(File srcDir, File destDir, FileFilter filter,
  604 |       boolean preserveFileDate, List<String> exclusionList) throws IOException {
  605 |     // recurse
  606 |     File[] srcFiles = filter == null ? srcDir.listFiles() : srcDir.listFiles(filter);
  607 |     if (srcFiles == null) {  // null if abstract pathname does not denote a directory, or if an I/O error occurs
  608 |       throw new IOException("Failed to list contents of " + srcDir);
  609 |     }
  610 |     if (destDir.exists()) {
  611 |       if (destDir.isDirectory() == false) {
  612 |         throw new IOException("Destination '" + destDir + "' exists but is not a directory");
  613 |       }
  614 |     } else {
  615 |       if (!destDir.mkdirs() && !destDir.isDirectory()) {
  616 |         throw new IOException("Destination '" + destDir + "' directory cannot be created");
  617 |       }
  618 |     }
  619 |     if (destDir.canWrite() == false) {
  620 |       throw new IOException("Destination '" + destDir + "' cannot be written to");
  621 |     }
  622 |     for (File srcFile : srcFiles) {
  623 |       File dstFile = new File(destDir, srcFile.getName());
  624 |       if (exclusionList == null || !exclusionList.contains(srcFile.getCanonicalPath())) {
  625 |         if (srcFile.isDirectory()) {
  626 |           doCopyDirectory(srcFile, dstFile, filter, preserveFileDate, exclusionList);
  627 |         } else {
  628 |           doCopyFile(srcFile, dstFile, preserveFileDate);
  629 |         }
  630 |       }
  631 |     }
  632 | 
  633 |     // Do this last, as the above has probably affected directory metadata
  634 |     if (preserveFileDate) {
  635 |       destDir.setLastModified(srcDir.lastModified());
  636 |     }
  637 |   }
  638 | 
  639 |   //-----------------------------------------------------------------------
  640 |   /**
```


---
# 8. spark / buggy / 81aa8a3fbd

## 73/113 flow_id 81aa8a3fbd (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 81aa8a3fbd
key        : <org.eclipse.jetty.server.ShutdownMonitor$ShutdownMonitorRunnable: void run()>@L124/result => <spark.resource.ClassPathResource: boolean exists()>@L122/0
source     : <org.eclipse.jetty.server.ShutdownMonitor$ShutdownMonitorRunnable: void run()>[30@L124] cmd = invokevirtual lin.readLine()/result
sink       : <spark.resource.ClassPathResource: boolean exists()>[10@L122] url = invokevirtual %v6.getResource(%v7)/0
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.ClassPathResource: boolean exists()>

## Code of the application methods on the route
### <spark.resource.ClassPathResource: boolean exists()>
file: spark/resource/ClassPathResource.java
  116 |     @Override
  117 |     public boolean exists() {
  118 |         URL url;
  119 |         if (this.clazz != null) {
  120 |             url = this.clazz.getResource(this.path);
  121 |         } else {
  122 |             url = this.classLoader.getResource(this.path);
  123 |         }
  124 |         return (url != null);
  125 |     }
  126 | 
  127 |     /**
```


---
# 9. zt-zip / buggy / 418972a9e1

## 42/115 flow_id 418972a9e1 (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 418972a9e1
key        : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1150/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyFile(java.io.File,java.io.File,boolean)>@L419/0
source     : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1150] %v7 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyFile(java.io.File,java.io.File,boolean)>[14@L419] invokespecial %v17.<init>(%v24)/0
fixed methods on this flow (GT): Unpacker.process
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyFile(java.io.File,java.io.File,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyFile(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  415 |    * @throws IOException if an error occurs
  416 |    */
  417 |   private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
  418 |     if (destFile.exists() && destFile.isDirectory()) {
  419 |       throw new IOException("Destination '" + destFile + "' exists but is a directory");
  420 |     }
  421 | 
  422 |     FileInputStream fis = null;
  423 |     FileOutputStream fos = null;
  424 |     FileChannel input = null;
  425 |     FileChannel output = null;
  426 |     try {
  427 |       fis = new FileInputStream(srcFile);
  428 |       fos = new FileOutputStream(destFile);
  429 |       input  = fis.getChannel();
  430 |       output = fos.getChannel();
  431 |       long size = input.size();
  432 |       long pos = 0;
  433 |       long count = 0;
  434 |       while (pos < size) {
  435 |         count = size - pos > FILE_COPY_BUFFER_SIZE ? FILE_COPY_BUFFER_SIZE : size - pos;
  436 |         pos += output.transferFrom(input, pos, count);
  437 |       }
  438 |     } finally {
  439 |       IOUtils.closeQuietly(output);
  440 |       IOUtils.closeQuietly(fos);
  441 |       IOUtils.closeQuietly(input);
  442 |       IOUtils.closeQuietly(fis);
  443 |     }
  444 | 
  445 |     if (srcFile.length() != destFile.length()) {
  446 |       throw new IOException("Failed to copy full contents from '" +
  447 |           srcFile + "' to '" + destFile + "'");
  448 |     }
  449 |     if (preserveFileDate) {
  450 |       destFile.setLastModified(srcFile.lastModified());
  451 |     }
  452 |   }
  453 | 
  454 |   /**
  455 |    * Copies a whole directory to a new location preserving the file dates.
```


---
# 10. spark / fixed / de79c00dfb

## 35/100 flow_id de79c00dfb (priority 1)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow de79c00dfb
key        : <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>@L67/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>[17@L67] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 11. zt-zip / buggy / ee08e9f40e

## 10/115 flow_id ee08e9f40e (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow ee08e9f40e
key        : <org.zeroturnaround.zip.ZipUtil$17: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L2573/result => <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1152/1
source     : <org.zeroturnaround.zip.ZipUtil$17: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L2573] %v5 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[7@L1152] invokespecial file.<init>(%v11, name)/1
fixed methods on this flow (GT): Unpacker.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v2 run2, v3 run0, v3 run1, v3 run2, v3-noV2 run0, v3-noV2 run1, v3-noV2 run2, v3-noV3 run0, v3-noV3 run1, v3-noV3 run2, v3-noval run0, v3-noval run1, v3-noval run2, v4 run0, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$17: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$17: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 2570 |         final Set<String> names = new HashSet<String>();
 2571 |         iterate(zip, new ZipEntryCallback() {
 2572 |           public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 2573 |             if (names.add(zipEntry.getName())) {
 2574 |               ZipEntrySource entry = (ZipEntrySource) entryByPath.remove(zipEntry.getName());
 2575 |               if (entry != null) {
 2576 |                 addEntry(entry, out);
 2577 |               }
 2578 |               else {
 2579 |                 ZipEntryUtil.copyEntry(zipEntry, in, out);
 2580 |               }
 2581 |             }
 2582 |             else if (log.isDebugEnabled()) {
 2583 |               log.debug("Duplicate entry: {}", zipEntry.getName());
 2584 |             }
 2585 |           }
 2586 |         });
 2587 |       }
 2588 |       finally {

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
 1278 |     }
 1279 | 
 1280 |     private String getRootName(final String name) {

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
```


---
# 12. zt-zip / buggy / 6080122b6a

## 81/115 flow_id 6080122b6a (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 6080122b6a
key        : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipInfoCallback)>@L629/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: java.io.FileOutputStream openOutputStream(java.io.File,boolean)>@L207/0
source     : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipInfoCallback)>[18@L629] %v18 = invokevirtual e.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: java.io.FileOutputStream openOutputStream(java.io.File,boolean)>[44@L207] invokespecial %v27.<init>(%v34)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipInfoCallback)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: java.io.FileOutputStream openOutputStream(java.io.File,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipInfoCallback)>
file: org/zeroturnaround/zip/ZipUtil.java
  615 |    * @see #iterate(File, ZipEntryCallback)
  616 |    */
  617 |   public static void iterate(File zip, ZipInfoCallback action) {
  618 |     ZipFile zf = null;
  619 |     try {
  620 |       zf = new ZipFile(zip);
  621 | 
  622 |       Enumeration<? extends ZipEntry> en = zf.entries();
  623 |       while (en.hasMoreElements()) {
  624 |         ZipEntry e = (ZipEntry) en.nextElement();
  625 |         try {
  626 |           action.process(e);
  627 |         }
  628 |         catch (IOException ze) {
  629 |           throw new ZipException("Failed to process zip entry '" + e.getName() + " with action " + action, ze);
  630 |         }
  631 |         catch (ZipBreakException ex) {
  632 |           break;
  633 |         }
  634 |       }
  635 |     }
  636 |     catch (IOException e) {
  637 |       throw ZipExceptionUtil.rethrow(e);
  638 |     }
  639 |     finally {
  640 |       closeQuietly(zf);
  641 |     }
  642 |   }
  643 | 
  644 |   /**
  645 |    * Scans the given ZIP file and executes the given action for each given entry.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: java.io.FileOutputStream openOutputStream(java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  193 |    * @since 2.1
  194 |    */
  195 |   public static FileOutputStream openOutputStream(File file, boolean append) throws IOException {
  196 |     if (file.exists()) {
  197 |       if (file.isDirectory()) {
  198 |         throw new IOException("File '" + file + "' exists but is a directory");
  199 |       }
  200 |       if (file.canWrite() == false) {
  201 |         throw new IOException("File '" + file + "' cannot be written to");
  202 |       }
  203 |     } else {
  204 |       File parent = file.getParentFile();
  205 |       if (parent != null) {
  206 |         if (!parent.mkdirs() && !parent.isDirectory()) {
  207 |           throw new IOException("Directory '" + parent + "' could not be created");
  208 |         }
  209 |       }
  210 |     }
  211 |     return new FileOutputStream(file, append);
  212 |   }
  213 | 
  214 |   //-----------------------------------------------------------------------
```


---
# 13. spark / buggy / 81ccc2b4b2

## 88/113 flow_id 81ccc2b4b2 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 81ccc2b4b2
key        : <spark.utils.StringUtils: java.lang.String collectionToDelimitedString(java.util.Collection,java.lang.String,java.lang.String,java.lang.String)>@L356/result => <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>@L141/0
source     : <spark.utils.StringUtils: java.lang.String collectionToDelimitedString(java.util.Collection,java.lang.String,java.lang.String,java.lang.String)>[11@L356] %v13 = invokeinterface it.next()/result
sink       : <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>[8@L141] is = invokevirtual %v6.getResourceAsStream(%v7)/0
fixed methods on this flow (GT): -
reported by: iris-like run2, v1 run2, v2 run2, v3 run2, v3-noV2 run2, v3-noV3 run2, v3-noval run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>, <spark.utils.StringUtils: java.lang.String collectionToDelimitedString(java.util.Collection,java.lang.String,java.lang.String,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>
file: spark/resource/ClassPathResource.java
  135 |     @Override
  136 |     public InputStream getInputStream() throws IOException {
  137 |         InputStream is;
  138 |         if (this.clazz != null) {
  139 |             is = this.clazz.getResourceAsStream(this.path);
  140 |         } else {
  141 |             is = this.classLoader.getResourceAsStream(this.path);
  142 |         }
  143 |         if (is == null) {
  144 |             throw new FileNotFoundException(getDescription() + " cannot be opened because it does not exist");
  145 |         }
  146 |         return is;
  147 |     }
  148 | 
  149 |     /**

### <spark.utils.StringUtils: java.lang.String collectionToDelimitedString(java.util.Collection,java.lang.String,java.lang.String,java.lang.String)>
file: spark/utils/StringUtils.java
  347 |      * @return the delimited String
  348 |      */
  349 |     public static String collectionToDelimitedString(Collection<?> coll, String delim, String prefix, String suffix) {
  350 |         if (CollectionUtils.isEmpty(coll)) {
  351 |             return "";
  352 |         }
  353 |         StringBuilder sb = new StringBuilder();
  354 |         Iterator<?> it = coll.iterator();
  355 |         while (it.hasNext()) {
  356 |             sb.append(prefix).append(it.next()).append(suffix);
  357 |             if (it.hasNext()) {
  358 |                 sb.append(delim);
  359 |             }
  360 |         }
  361 |         return sb.toString();
  362 |     }
  363 | 
  364 |     /**
```


---
# 14. spark / fixed / 5c865fd068

## 66/100 flow_id 5c865fd068 (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 5c865fd068
key        : <org.eclipse.jetty.websocket.servlet.UpgradeHttpServletRequest: void <init>(javax.servlet.http.HttpServletRequest)>@L130/result => <spark.embeddedserver.jetty.websocket.WebSocketServletContextHandlerFactory: org.eclipse.jetty.servlet.ServletContextHandler create(java.util.Map,java.util.Optional)>@L55/0
source     : <org.eclipse.jetty.websocket.servlet.UpgradeHttpServletRequest: void <init>(javax.servlet.http.HttpServletRequest)>[86@L130] %v54 = invokeinterface httpRequest.getServerName()/result
sink       : <spark.embeddedserver.jetty.websocket.WebSocketServletContextHandlerFactory: org.eclipse.jetty.servlet.ServletContextHandler create(java.util.Map,java.util.Optional)>[28@L55] invokespecial %v28.<init>(path)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.embeddedserver.jetty.websocket.WebSocketServletContextHandlerFactory: org.eclipse.jetty.servlet.ServletContextHandler create(java.util.Map,java.util.Optional)>

## Code of the application methods on the route
### <spark.embeddedserver.jetty.websocket.WebSocketServletContextHandlerFactory: org.eclipse.jetty.servlet.ServletContextHandler create(java.util.Map,java.util.Optional)>
file: spark/embeddedserver/jetty/websocket/WebSocketServletContextHandlerFactory.java
   42 |      */
   43 |     public static ServletContextHandler create(Map<String, WebSocketHandlerWrapper> webSocketHandlers,
   44 |                                                Optional<Integer> webSocketIdleTimeoutMillis) {
   45 |         ServletContextHandler webSocketServletContextHandler = null;
   46 |         if (webSocketHandlers != null) {
   47 |             try {
   48 |                 webSocketServletContextHandler = new ServletContextHandler(null, "/", true, false);
   49 |                 WebSocketUpgradeFilter webSocketUpgradeFilter = WebSocketUpgradeFilter.configureContext(webSocketServletContextHandler);
   50 |                 if (webSocketIdleTimeoutMillis.isPresent()) {
   51 |                     webSocketUpgradeFilter.getFactory().getPolicy().setIdleTimeout(webSocketIdleTimeoutMillis.get());
   52 |                 }
   53 |                 for (String path : webSocketHandlers.keySet()) {
   54 |                     WebSocketCreator webSocketCreator = WebSocketCreatorFactory.create(webSocketHandlers.get(path));
   55 |                     webSocketUpgradeFilter.addMapping(new ServletPathSpec(path), webSocketCreator);
   56 |                 }
   57 |             } catch (Exception ex) {
   58 |                 logger.error("creation of websocket context handler failed.", ex);
   59 |                 webSocketServletContextHandler = null;
   60 |             }
   61 |         }
   62 |         return webSocketServletContextHandler;
   63 |     }
   64 | 
   65 | }
```


---
# 15. perfecto-plugin / buggy / 05a565b1c4

## 1/4 flow_id 05a565b1c4 (priority 1)

```text
# perfecto-plugin/buggy (CVE-2020-2261, CWE-078) flow 05a565b1c4
key        : DRIVER => <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>@L167/0[*]
source     : <nesy.NesyDriver: void main(java.lang.String[])>[56@L19] %v37 = invokestatic nesy.Taint.src()/result
sink       : <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[104@L167] process = invokevirtual %v93.exec(cmdArgs#1)/0[*]
fixed methods on this flow (GT): PerfectoBuildWrapper.getTunnelId, PerfectoBuildWrapper.PerfectoBuildWrapper
reported by: B2 run0, v4 run1, v4 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[83@L24] %v53 = invokestatic nesy.Taint.src()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v53}
3. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>/perfectoConnectLocation}
4. InstanceFieldNode{NewObj{<nesy.NesyDriver: void main(java.lang.String[])>[52@L19] new io.plugins.perfecto.PerfectoBuildWrapper}.<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String perfectoConnectLocation>}
5. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>/%v26}
6. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/perfectoConnectLocation}
7. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v82}
8. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v83}
9. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v85}
10. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v86}
11. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v90}
12. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v91}
13. VarNode{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>/%v92}
14. ArrayIndexNode{NewObj{<io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[81@L166] newarray java.lang.String[%ci3]}}
15. <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>[104@L167] process = invokevirtual %v93.exec(cmdArgs#1)/0[*]

## Code of the application methods on the route
### <io.plugins.perfecto.PerfectoBuildWrapper: void setPerfectoConnectLocation(java.lang.String)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  280 | 	}
  281 | 
  282 | 	public void setPerfectoConnectLocation(String perfectoConnectLocation) {
  283 | 		this.perfectoConnectLocation = perfectoConnectLocation;
  284 | 	}
  285 | 
  286 | 	public String getSecurityToken() {
  287 | 		return perfectoSecurityToken;

### <io.plugins.perfecto.PerfectoBuildWrapper: hudson.tasks.BuildWrapper$Environment setUp(hudson.model.AbstractBuild,hudson.Launcher,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  203 | 	 */
  204 | 	@Override
  205 | 	public Environment setUp(final AbstractBuild build, Launcher launcher, final BuildListener listener) throws IOException, InterruptedException {
  206 | 		listener.getLogger().println("Creating Tunnel Id........!");
  207 | 		logger.fine("Setting Perfecto Build Wrapper");
  208 | 
  209 | 		credentials = PerfectoCredentials.getPerfectoCredentials(build, this);
  210 | 		CredentialsProvider.track(build, credentials);
  211 | 
  212 | 		if(credentials==null && !reuseTunnelId.contains("-")) {
  213 | 			listener.fatalError("Credentials missing......");
  214 | 			throw new IOException("Credentials missing......");
  215 | 		}
  216 | 
  217 | 		if(!reuseTunnelId.contains("-")) {
  218 | 			final String apiKey = credentials.getPassword().getPlainText();
  219 | 			tunnelId = getTunnelId(perfectoConnectLocation, credentials.getCloudName(), apiKey, listener);
  220 | 		}
  221 | 		else
  222 | 			tunnelId = reuseTunnelId;
  223 | 		listener.getLogger().println("Tunnel Id created succesfully.");
  224 | 
  225 | 		return new Environment() {
  226 | 
  227 | 			/**
  228 | 			 * Updates the environment variable map to include the Perfecto specific environment variables applicable to the build.

### <io.plugins.perfecto.PerfectoBuildWrapper: java.lang.String getTunnelId(java.lang.String,java.lang.String,java.lang.String,hudson.model.BuildListener)>
file: io/plugins/perfecto/PerfectoBuildWrapper.java
  149 | 	}
  150 | 
  151 | 	private String getTunnelId(String perfectoConnectLocation, String cloudName, String apiKey, BuildListener listener) throws IOException {
  152 | 		String tunnelId = null;
  153 | 		boolean isWindows = hudson.Functions.isWindows();
  154 | 		Process process;
  155 | 		if(perfectoConnectLocation.endsWith("/")||perfectoConnectLocation.endsWith("\\")) {
  156 | 			pcLocation = perfectoConnectLocation+perfectoConnectFile;
  157 | 		}else {
  158 | 			pcLocation = perfectoConnectLocation+File.separator+perfectoConnectFile;
  159 | 		}
  160 | 		String baseCommand = pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s "+apiKey.trim();
  161 | 		listener.getLogger().println(pcLocation.trim()+" start -c "+cloudName.trim()+".perfectomobile.com -s <<TOKEN>> "+pcParameters.trim());
  162 | 		if (isWindows) {
  163 | 			String cmdArgs[] = {"cmd.exe", "/c", baseCommand+" "+pcParameters.trim()};
  164 | 			process = new ProcessBuilder(cmdArgs).redirectErrorStream(true).start();
  165 | 		} else {
  166 | 			String cmdArgs[] = {"bash", "-c", "(cd "+perfectoConnectLocation+"; "+baseCommand+" "+pcParameters.trim()+")"};
  167 | 			process = Runtime.getRuntime().exec(cmdArgs);
  168 | 		}
  169 | 		InputStream is = process.getInputStream();
  170 | 		BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
  171 | 		String s = null;
  172 | 		while ((s = reader.readLine()) != null) {
  173 | 			listener.getLogger().println(s);
  174 | 			Matcher m = Pattern.compile("^[A-Za-z0-9-]+$").matcher(s);
  175 | 			if (m.find()) {
  176 | 				tunnelId = m.group(0);
  177 | 				listener.getLogger().println("Tunnel Id : "+tunnelId);
  178 | 			}
  179 | 			if(s.contains("bash: ")) {
  180 | 				listener.fatalError("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  181 | 				throw new IOException("Perfecto Connect Path and Name is not Correct. Path Provided : '"+pcLocation+"'");
  182 | 			}
  183 | 			if(s.contains("Can't start Perfecto Connect")||s.contains("failed to start")) {
  184 | 				listener.fatalError(tunnelId);
  185 | 				throw new IOException(tunnelId);
  186 | 			}
  187 | 		}
  188 | 		reader.close();
  189 | 		if(tunnelId == null) {
  190 | 			listener.fatalError("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  191 | 			throw new IOException("Unable to create tunnel ID. Kindly cross check your parameters or raise a Perfecto support case.");
  192 | 		}
  193 | 		return tunnelId;
  194 | 	}
  195 | 
  196 | 
```


---
# 16. zt-zip / buggy / d694052c21

## 4/115 flow_id d694052c21 (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow d694052c21
key        : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1150/result => <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1214/0
source     : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1150] %v7 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[19@L1214] invokespecial file.<init>(parentDirectory, %v22)/0
fixed methods on this flow (GT): Unpacker.process
reported by: B2 run0

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtils.java
   51 |    * @throws java.io.IOException if file is not found or copying fails
   52 |    */
   53 |   public static void copy(InputStream in, File file) throws IOException {
   54 |     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
   55 |     try {
   56 |       IOUtils.copy(in, out);
   57 |     }
   58 |     finally {
   59 |       IOUtils.closeQuietly(out);
   60 |     }
   61 |   }
   62 | 
   63 |   /**
   64 |    * Find a non-existing file in the same directory using the same name as prefix.
```


---
# 17. spark / fixed / c7aefb4da3

## 84/100 flow_id c7aefb4da3 (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow c7aefb4da3
key        : <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>@L102/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>@L258/0
source     : <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>[14@L102] acceptType = invokeinterface httpRequest.getHeader(%c26)/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>[19@L258] invokespecial %v14.<init>(%v15)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>

## Code of the application methods on the route
### <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>
file: spark/http/matching/MatcherFilter.java
   85 |                          ServletResponse servletResponse,
   86 |                          FilterChain chain) throws IOException, ServletException {
   87 | 
   88 |         HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
   89 |         HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;
   90 | 
   91 |         // handle static resources
   92 |         boolean consumedByStaticFile = staticFiles.consume(httpRequest, httpResponse);
   93 | 
   94 |         if (consumedByStaticFile) {
   95 |             return;
   96 |         }
   97 | 
   98 |         String method = getHttpMethodFrom(httpRequest);
   99 | 
  100 |         String httpMethodStr = method.toLowerCase();
  101 |         String uri = httpRequest.getRequestURI();
  102 |         String acceptType = httpRequest.getHeader(ACCEPT_TYPE_REQUEST_MIME_HEADER);
  103 | 
  104 |         Body body = Body.create();
  105 | 
  106 |         RequestWrapper requestWrapper = RequestWrapper.create();
  107 |         ResponseWrapper responseWrapper = ResponseWrapper.create();
  108 | 
  109 |         Response response = RequestResponseFactory.create(httpResponse);
  110 | 
  111 |         HttpMethod httpMethod = HttpMethod.get(httpMethodStr);
  112 | 
  113 |         RouteContext context = RouteContext.create()
  114 |                 .withMatcher(routeMatcher)
      | ... (lines omitted) ...
  139 | 
  140 |         // If redirected and content is null set to empty string to not throw NotConsumedException
  141 |         if (body.notSet() && responseWrapper.isRedirected()) {
  142 |             body.set("");
  143 |         }
  144 | 
  145 |         if (body.notSet() && hasOtherHandlers) {
  146 |             if (servletRequest instanceof HttpRequestWrapper) {
  147 |                 ((HttpRequestWrapper) servletRequest).notConsumed(true);
  148 |                 return;
  149 |             }
  150 |         }
  151 | 
  152 |         if (body.notSet() && !externalContainer) {
  153 |             LOG.info("The requested route [{}] has not been mapped in Spark for {}: [{}]",
  154 |                 uri, ACCEPT_TYPE_REQUEST_MIME_HEADER, acceptType);
  155 |             httpResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
  156 |             body.set(String.format(NOT_FOUND));
  157 |         }
  158 | 
  159 |         if (body.isSet()) {
  160 |             body.serializeTo(httpResponse, serializerChain, httpRequest);
  161 | 
  162 |         } else if (chain != null) {
  163 |             chain.doFilter(httpRequest, httpResponse);
  164 |         }
  165 |     }
  166 | 
  167 |     private String getHttpMethodFrom(HttpServletRequest httpRequest) {
  168 |         String method = httpRequest.getHeader(HTTP_METHOD_OVERRIDE_HEADER);

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>
file: spark/utils/ResourceUtils.java
  248 |      *                               a file in the file system
  249 |      */
  250 |     public static File getFile(URI resourceUri, String description) throws FileNotFoundException {
  251 |         Assert.notNull(resourceUri, "Resource URI must not be null");
  252 |         if (!URL_PROTOCOL_FILE.equals(resourceUri.getScheme())) {
  253 |             throw new FileNotFoundException(
  254 |                     description + " cannot be resolved to absolute file path " +
  255 |                             "because it does not reside in the file system: " + resourceUri
  256 |             );
  257 |         }
  258 |         return new File(resourceUri.getSchemeSpecificPart());
  259 |     }
  260 | 
  261 |     /**
```


---
# 18. zt-zip / buggy / 48172fd182

## 3/115 flow_id 48172fd182 (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 48172fd182
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1258/result => <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>@L61/0
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[24@L1258] %v24 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>[7@L61] invokespecial copy.<init>(%v5)/0
fixed methods on this flow (GT): Unwraper.process
reported by: iris-like run0, v1 run0, v2 run0, v3 run0, v3-noV2 run0, v3-noV3 run0, v3-noval run0, v4 run0

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry fromFile(java.lang.String,java.io.File)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry fromFile(java.lang.String,java.io.File)>
file: org/zeroturnaround/zip/ZipEntryUtil.java
  141 |    * @return newly created Zip entry
  142 |    */
  143 |   static ZipEntry fromFile(String name, File file) {
  144 |     ZipEntry zipEntry = new ZipEntry(name);
  145 |     if (!file.isDirectory()) {
  146 |       zipEntry.setSize(file.length());
  147 |     }
  148 |     zipEntry.setTime(file.lastModified());
  149 | 
  150 |     ZTFilePermissions permissions = ZTFilePermissionsUtil.getDefaultStategy().getPermissions(file);
  151 |     if (permissions != null) {
  152 |       ZipEntryUtil.setZTFilePermissions(zipEntry, permissions);
  153 |     }
  154 |     return zipEntry;
  155 |   }
  156 | 
  157 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
 1278 |     }
 1279 | 
 1280 |     private String getRootName(final String name) {

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>
file: org/zeroturnaround/zip/ZipEntryUtil.java
   58 |    * @return copy of the original entry, but with the given name
   59 |    */
   60 |   static ZipEntry copy(ZipEntry original, String newName) {
   61 |     ZipEntry copy = new ZipEntry(newName == null ? original.getName() : newName);
   62 |     if (original.getCrc() != -1) {
   63 |       copy.setCrc(original.getCrc());
   64 |     }
   65 |     if (original.getMethod() != -1) {
   66 |       copy.setMethod(original.getMethod());
   67 |     }
   68 |     if (original.getSize() >= 0) {
   69 |       copy.setSize(original.getSize());
   70 |     }
   71 |     if (original.getExtra() != null) {
   72 |       copy.setExtra(original.getExtra());
   73 |     }
   74 | 
   75 |     copy.setComment(original.getComment());
   76 |     copy.setTime(original.getTime());
   77 |     return copy;
   78 |   }
   79 | 
   80 |   /**
```


---
# 19. spark / buggy / 97393d333c

## 41/113 flow_id 97393d333c (priority 1)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 97393d333c
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L55/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[21@L55] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 20. zt-zip / fixed / 476fe4a413

## 72/97 flow_id 476fe4a413 (priority 2)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 476fe4a413
key        : <org.apache.log4j.helpers.Loader: java.lang.Class loadClass(java.lang.String)>@L182/0 => <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.util.zip.ZipOutputStream,org.zeroturnaround.zip.NameMapper,java.lang.String,boolean)>@L1766/1
source     : <org.apache.log4j.helpers.Loader: java.lang.Class loadClass(java.lang.String)>[5@L182] %v15 = invokestatic java.lang.Class.forName(clazz)/0
sink       : <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.util.zip.ZipOutputStream,org.zeroturnaround.zip.NameMapper,java.lang.String,boolean)>[47@L1766] invokespecial file.<init>(dir, filename)/1
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.util.zip.ZipOutputStream,org.zeroturnaround.zip.NameMapper,java.lang.String,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.util.zip.ZipOutputStream,org.zeroturnaround.zip.NameMapper,java.lang.String,boolean)>
file: org/zeroturnaround/zip/ZipUtil.java
 1749 |    *          if true, but directory to pack doesn't have any files, throw an exception.
 1750 |    */
 1751 |   private static void pack(File dir, ZipOutputStream out, NameMapper mapper, String pathPrefix, boolean mustHaveChildren) throws IOException {
 1752 |     String[] filenames = dir.list();
 1753 |     if (filenames == null) {
 1754 |       if (!dir.exists()) {
 1755 |         throw new ZipException("Given file '" + dir + "' doesn't exist!");
 1756 |       }
 1757 |       throw new IOException("Given file is not a directory '" + dir + "'");
 1758 |     }
 1759 | 
 1760 |     if (mustHaveChildren && filenames.length == 0) {
 1761 |       throw new ZipException("Given directory '" + dir + "' doesn't contain any files!");
 1762 |     }
 1763 | 
 1764 |     for (int i = 0; i < filenames.length; i++) {
 1765 |       String filename = filenames[i];
 1766 |       File file = new File(dir, filename);
 1767 |       boolean isDir = file.isDirectory();
 1768 |       String path = pathPrefix + file.getName(); // NOSONAR
 1769 |       if (isDir) {
 1770 |         path += PATH_SEPARATOR; // NOSONAR
 1771 |       }
 1772 | 
 1773 |       // Create a ZIP entry
 1774 |       String name = mapper.map(path);
 1775 |       if (name != null) {
 1776 |         ZipEntry zipEntry = ZipEntryUtil.fromFile(name, file);
 1777 | 
 1778 |         out.putNextEntry(zipEntry);
 1779 | 
 1780 |         // Copy the file content
 1781 |         if (!isDir) {
 1782 |           FileUtils.copy(file, out);
 1783 |         }
 1784 | 
 1785 |         out.closeEntry();
 1786 |       }
 1787 | 
 1788 |       // Traverse the directory
 1789 |       if (isDir) {
 1790 |         pack(file, out, mapper, path, false);
 1791 |       }
 1792 |     }
 1793 |   }
 1794 | 
 1795 |   /**
 1796 |    * Repacks a provided ZIP file into a new ZIP with a given compression level.
```


---
# 21. spark / buggy / e118e9ee98

## 97/113 flow_id e118e9ee98 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow e118e9ee98
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L51/result => <spark.resource.ClassPathResource: java.net.URL getURL()>@L163/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[18@L51] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.resource.ClassPathResource: java.net.URL getURL()>[8@L163] url = invokevirtual %v6.getResource(%v7)/0
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResource: java.net.URL getURL()>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResource: java.net.URL getURL()>
file: spark/resource/ClassPathResource.java
  157 |     @Override
  158 |     public URL getURL() throws IOException {
  159 |         URL url;
  160 |         if (this.clazz != null) {
  161 |             url = this.clazz.getResource(this.path);
  162 |         } else {
  163 |             url = this.classLoader.getResource(this.path);
  164 |         }
  165 |         if (url == null) {
  166 |             throw new FileNotFoundException(getDescription() + " cannot be resolved to URL because it does not exist");
  167 |         }
  168 |         return url;
  169 |     }
  170 | 
  171 |     /**
```


---
# 22. zt-zip / buggy / e7c1d100ba

## 93/115 flow_id e7c1d100ba (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow e7c1d100ba
key        : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1196/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>@L404/0
source     : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[4@L1196] %v9 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>[85@L404] invokespecial %v55.<init>(%v62)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  379 |    */
  380 |   public static void copyFile(File srcFile, File destFile,
  381 |       boolean preserveFileDate) throws IOException {
  382 |     if (srcFile == null) {
  383 |       throw new NullPointerException("Source must not be null");
  384 |     }
  385 |     if (destFile == null) {
  386 |       throw new NullPointerException("Destination must not be null");
  387 |     }
  388 |     if (srcFile.exists() == false) {
  389 |       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
  390 |     }
  391 |     if (srcFile.isDirectory()) {
  392 |       throw new IOException("Source '" + srcFile + "' exists but is a directory");
  393 |     }
  394 |     if (srcFile.getCanonicalPath().equals(destFile.getCanonicalPath())) {
  395 |       throw new IOException("Source '" + srcFile + "' and destination '" + destFile + "' are the same");
  396 |     }
  397 |     File parentFile = destFile.getParentFile();
  398 |     if (parentFile != null) {
  399 |       if (!parentFile.mkdirs() && !parentFile.isDirectory()) {
  400 |         throw new IOException("Destination '" + parentFile + "' directory cannot be created");
  401 |       }
  402 |     }
  403 |     if (destFile.exists() && destFile.canWrite() == false) {
  404 |       throw new IOException("Destination '" + destFile + "' exists but is read-only");
  405 |     }
  406 |     doCopyFile(srcFile, destFile, preserveFileDate);
  407 |   }
  408 | 
  409 |   /**
  410 |    * Internal copy file method.
```


---
# 23. zt-zip / buggy / 5b9053b93d

## 56/115 flow_id 5b9053b93d (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 5b9053b93d
key        : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1196/result => <org.zeroturnaround.zip.ZTFileUtil: void innerListFiles(java.io.File,java.util.Collection,java.io.FileFilter)>@L57/1
source     : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[4@L1196] %v9 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZTFileUtil: void innerListFiles(java.io.File,java.util.Collection,java.io.FileFilter)>[9@L57] invokespecial file.<init>(dir, %v11)/1
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZTFileUtil: void innerListFiles(java.io.File,java.util.Collection,java.io.FileFilter)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZTFileUtil: void innerListFiles(java.io.File,java.util.Collection,java.io.FileFilter)>
file: org/zeroturnaround/zip/ZTFileUtil.java
   50 | 
   51 |   private static void innerListFiles(File dir, Collection<File> accumulator, FileFilter filter) {
   52 | 
   53 |     String[] filenames = dir.list();
   54 | 
   55 |     if (filenames != null) {
   56 |       for (int i = 0; i < filenames.length; i++) {
   57 |         File file = new File(dir, filenames[i]);
   58 |         if (file.isDirectory()) {
   59 |           innerListFiles(file, accumulator, filter);
   60 |         }
   61 |         else {
   62 |           if (filter != null && filter.accept(file)) {
   63 |             accumulator.add(file);
   64 |           }
   65 |         }
   66 |       }
   67 |     }
   68 |   }
   69 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtils.java
   51 |    * @throws java.io.IOException if file is not found or copying fails
   52 |    */
   53 |   public static void copy(InputStream in, File file) throws IOException {
   54 |     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
   55 |     try {
   56 |       IOUtils.copy(in, out);
   57 |     }
   58 |     finally {
   59 |       IOUtils.closeQuietly(out);
   60 |     }
   61 |   }
   62 | 
   63 |   /**
   64 |    * Find a non-existing file in the same directory using the same name as prefix.
```


---
# 24. spark / fixed / 79d672ed42

## 57/100 flow_id 79d672ed42 (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 79d672ed42
key        : <org.eclipse.jetty.http.HttpParser: boolean parseHeaders(java.nio.ByteBuffer)>@L1002/result => <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>@L183/0
source     : <org.eclipse.jetty.http.HttpParser: boolean parseHeaders(java.nio.ByteBuffer)>[192@L1002] v = invokevirtual field.getValue()/result
sink       : <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>[14@L183] invokespecial %v9.<init>(%v11)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.eclipse.jetty.http.HttpParser: boolean parseHeaders(java.nio.ByteBuffer)>, <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>

## Code of the application methods on the route
(no application code available)
```


---
# 25. spark / buggy / ff183e0172

## 67/113 flow_id ff183e0172 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow ff183e0172
key        : <org.eclipse.jetty.server.handler.gzip.GzipHandler: void handle(java.lang.String,org.eclipse.jetty.server.Request,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>@L419/result => <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>@L183/0
source     : <org.eclipse.jetty.server.handler.gzip.GzipHandler: void handle(java.lang.String,org.eclipse.jetty.server.Request,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>[103@L419] etag = invokevirtual %v64.get(%v65)/result
sink       : <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>[14@L183] invokespecial %v9.<init>(%v11)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.eclipse.jetty.server.handler.gzip.GzipHandler: void handle(java.lang.String,org.eclipse.jetty.server.Request,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)>, <org.eclipse.jetty.util.resource.URLResource: java.io.File getFile()>

## Code of the application methods on the route
(no application code available)
```


---
# 26. spark / fixed / 40a3b1c77e

## 29/100 flow_id 40a3b1c77e (priority 1)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 40a3b1c77e
key        : <org.eclipse.jetty.server.Server: void handleAsync(org.eclipse.jetty.server.HttpChannel)>@L553/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <org.eclipse.jetty.server.Server: void handleAsync(org.eclipse.jetty.server.HttpChannel)>[21@L553] %v23 = invokevirtual uri.getQuery()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 27. spark / buggy / ef672a64e1

## 62/113 flow_id ef672a64e1 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow ef672a64e1
key        : <org.eclipse.jetty.websocket.servlet.UpgradeHttpServletRequest: void <init>(javax.servlet.http.HttpServletRequest)>@L114/result => <org.eclipse.jetty.util.MultiPartInputStreamParser: void parse()>@L460/0
source     : <org.eclipse.jetty.websocket.servlet.UpgradeHttpServletRequest: void <init>(javax.servlet.http.HttpServletRequest)>[57@L114] %v35 = invokeinterface httpRequest.getHeaders(name)/result
sink       : <org.eclipse.jetty.util.MultiPartInputStreamParser: void parse()>[36@L460] invokespecial f.<init>(%v46)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.eclipse.jetty.util.MultiPartInputStreamParser: void parse()>, <org.eclipse.jetty.websocket.servlet.UpgradeHttpServletRequest: void <init>(javax.servlet.http.HttpServletRequest)>

## Code of the application methods on the route
(no application code available)
```


---
# 28. spark / buggy / e1b93f1b2b

## 38/113 flow_id e1b93f1b2b (priority 1)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow e1b93f1b2b
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L50/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[17@L50] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 29. zt-zip / fixed / ed238c5914

## 87/97 flow_id ed238c5914 (priority 2)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow ed238c5914
key        : DRIVER => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>@L584/0
source     : <nesy.NesyDriver: void main(java.lang.String[])>[619@L119] %v389 = invokestatic nesy.Taint.srcFile()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>[78@L584] invokespecial copiedFile.<init>(destDir, %v59)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[635@L122] %v399 = invokestatic nesy.Taint.srcFile()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v399}
3. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveDirectory(java.io.File,java.io.File)>/destDir}
4. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File)>/destDir}
5. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,boolean)>/destDir}
6. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>/destDir}
7. <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>[78@L584] invokespecial copiedFile.<init>(destDir, %v59)/0

## Code of the application methods on the route
### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveDirectory(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  980 |    * @since 1.4
  981 |    */
  982 |   public static void moveDirectory(File srcDir, File destDir) throws IOException {
  983 |     if (srcDir == null) {
  984 |       throw new NullPointerException("Source must not be null");
  985 |     }
  986 |     if (destDir == null) {
  987 |       throw new NullPointerException("Destination must not be null");
  988 |     }
  989 |     if (!srcDir.exists()) {
  990 |       throw new FileNotFoundException("Source '" + srcDir + "' does not exist");
  991 |     }
  992 |     if (!srcDir.isDirectory()) {
  993 |       throw new IOException("Source '" + srcDir + "' is not a directory");
  994 |     }
  995 |     if (destDir.exists()) {
  996 |       throw new FileExistsException("Destination '" + destDir + "' already exists");
  997 |     }
  998 |     boolean rename = srcDir.renameTo(destDir);
  999 |     if (!rename) {
 1000 |       if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
 1001 |         throw new IOException("Cannot move directory: "+srcDir+" to a subdirectory of itself: "+destDir);
 1002 |       }
 1003 |       copyDirectory( srcDir, destDir );
 1004 |       deleteDirectory( srcDir );
 1005 |       if (srcDir.exists()) {
 1006 |         throw new IOException("Failed to delete original directory '" + srcDir +
 1007 |             "' after copy to '" + destDir + "'");
 1008 |       }
 1009 |     }
 1010 |   }
 1011 | 
 1012 |   /**
 1013 |    * Moves a file.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  476 |    * @since 1.1
  477 |    */
  478 |   public static void copyDirectory(File srcDir, File destDir) throws IOException {
  479 |     copyDirectory(srcDir, destDir, true);
  480 |   }
  481 | 
  482 |   /**
  483 |    * Copies a whole directory to a new location.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  507 |    */
  508 |   public static void copyDirectory(File srcDir, File destDir,
  509 |       boolean preserveFileDate) throws IOException {
  510 |     copyDirectory(srcDir, destDir, null, preserveFileDate);
  511 |   }
  512 | 
  513 |   /**
  514 |    * Copies a filtered directory to a new location.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  558 |    */
  559 |   public static void copyDirectory(File srcDir, File destDir,
  560 |       FileFilter filter, boolean preserveFileDate) throws IOException {
  561 |     if (srcDir == null) {
  562 |       throw new NullPointerException("Source must not be null");
  563 |     }
  564 |     if (destDir == null) {
  565 |       throw new NullPointerException("Destination must not be null");
  566 |     }
  567 |     if (srcDir.exists() == false) {
  568 |       throw new FileNotFoundException("Source '" + srcDir + "' does not exist");
  569 |     }
  570 |     if (srcDir.isDirectory() == false) {
  571 |       throw new IOException("Source '" + srcDir + "' exists but is not a directory");
  572 |     }
  573 |     if (srcDir.getCanonicalPath().equals(destDir.getCanonicalPath())) {
  574 |       throw new IOException("Source '" + srcDir + "' and destination '" + destDir + "' are the same");
  575 |     }
  576 | 
  577 |     // Cater for destination being directory within the source directory (see IO-141)
  578 |     List<String> exclusionList = null;
  579 |     if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
  580 |       File[] srcFiles = filter == null ? srcDir.listFiles() : srcDir.listFiles(filter);
  581 |       if (srcFiles != null && srcFiles.length > 0) {
  582 |         exclusionList = new ArrayList<String>(srcFiles.length);
  583 |         for (File srcFile : srcFiles) {
  584 |           File copiedFile = new File(destDir, srcFile.getName());
  585 |           exclusionList.add(copiedFile.getCanonicalPath());
  586 |         }
  587 |       }
  588 |     }
  589 |     doCopyDirectory(srcDir, destDir, filter, preserveFileDate, exclusionList);
  590 |   }
  591 | 
  592 |   /**
  593 |    * Internal copy directory method.
```


---
# 30. spark / buggy / 268b43a5e9

## 105/113 flow_id 268b43a5e9 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 268b43a5e9
key        : <org.eclipse.jetty.server.Request: java.lang.String getQueryString()>@L1141/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>@L258/0
source     : <org.eclipse.jetty.server.Request: java.lang.String getQueryString()>[2@L1141] %v3 = invokevirtual %v2.getQuery()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>[19@L258] invokespecial %v14.<init>(%v15)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>

## Code of the application methods on the route
### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>
file: spark/utils/ResourceUtils.java
  248 |      *                               a file in the file system
  249 |      */
  250 |     public static File getFile(URI resourceUri, String description) throws FileNotFoundException {
  251 |         Assert.notNull(resourceUri, "Resource URI must not be null");
  252 |         if (!URL_PROTOCOL_FILE.equals(resourceUri.getScheme())) {
  253 |             throw new FileNotFoundException(
  254 |                     description + " cannot be resolved to absolute file path " +
  255 |                             "because it does not reside in the file system: " + resourceUri
  256 |             );
  257 |         }
  258 |         return new File(resourceUri.getSchemeSpecificPart());
  259 |     }
  260 | 
  261 |     /**
```


---
# 31. zt-zip / buggy / 6db049dc40

## 87/115 flow_id 6db049dc40 (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 6db049dc40
key        : DRIVER => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>@L399/base
source     : <nesy.NesyDriver: void main(java.lang.String[])>[172@L72] %v107 = invokestatic nesy.Taint.srcFile()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>[57@L399] %v43 = invokevirtual parentFile.mkdirs()/base
fixed methods on this flow (GT): -
reported by: iris-like run2, v1 run2, v2 run2, v3 run2, v3-noV2 run2, v3-noV3 run2, v3-noval run2, v4 run2

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[176@L75] %v110 = invokestatic nesy.Taint.srcFile()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v110}
3. VarNode{<org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>/dir}
4. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveFile(java.io.File,java.io.File)>/destFile}
5. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File)>/destFile}
6. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>/destFile}
7. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>/parentFile}
8. <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>[57@L399] %v43 = invokevirtual parentFile.mkdirs()/base

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>
file: org/zeroturnaround/zip/ZipUtil.java
 1895 |   public static void unexplode(File dir, int compressionLevel) {
 1896 |     try {
 1897 |       // Find a new unique name is the same directory
 1898 |       File zip = FileUtils.getTempFileFor(dir);
 1899 | 
 1900 |       // Pack it
 1901 |       pack(dir, zip, compressionLevel);
 1902 | 
 1903 |       // Delete the directory
 1904 |       FileUtils.deleteDirectory(dir);
 1905 | 
 1906 |       // Rename the archive
 1907 |       FileUtils.moveFile(zip, dir);
 1908 |     }
 1909 |     catch (IOException e) {
 1910 |       throw ZipExceptionUtil.rethrow(e);
 1911 |     }
 1912 |   }
 1913 | 
 1914 |   /**
 1915 |    * Compresses the given entries into an output stream.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveFile(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
 1023 |    * @since 1.4
 1024 |    */
 1025 |   public static void moveFile(File srcFile, File destFile) throws IOException {
 1026 |     if (srcFile == null) {
 1027 |       throw new NullPointerException("Source must not be null");
 1028 |     }
 1029 |     if (destFile == null) {
 1030 |       throw new NullPointerException("Destination must not be null");
 1031 |     }
 1032 |     if (!srcFile.exists()) {
 1033 |       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
 1034 |     }
 1035 |     if (srcFile.isDirectory()) {
 1036 |       throw new IOException("Source '" + srcFile + "' is a directory");
 1037 |     }
 1038 |     if (destFile.exists()) {
 1039 |       throw new FileExistsException("Destination '" + destFile + "' already exists");
 1040 |     }
 1041 |     if (destFile.isDirectory()) {
 1042 |       throw new IOException("Destination '" + destFile + "' is a directory");
 1043 |     }
 1044 |     boolean rename = srcFile.renameTo(destFile);
 1045 |     if (!rename) {
 1046 |       copyFile( srcFile, destFile );
 1047 |       if (!srcFile.delete()) {
 1048 |         FileUtils.deleteQuietly(destFile);
 1049 |         throw new IOException("Failed to delete original file '" + srcFile +
 1050 |             "' after copy to '" + destFile + "'");
 1051 |       }
 1052 |     }
 1053 |   }
 1054 | 
 1055 |   /**
 1056 |    * Determines whether the specified file is a Symbolic Link rather than an actual file.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  350 |    * @see #copyFileToDirectory(File, File)
  351 |    */
  352 |   public static void copyFile(File srcFile, File destFile) throws IOException {
  353 |     copyFile(srcFile, destFile, true);
  354 |   }
  355 | 
  356 |   /**
  357 |    * Copies a file to a new location.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  379 |    */
  380 |   public static void copyFile(File srcFile, File destFile,
  381 |       boolean preserveFileDate) throws IOException {
  382 |     if (srcFile == null) {
  383 |       throw new NullPointerException("Source must not be null");
  384 |     }
  385 |     if (destFile == null) {
  386 |       throw new NullPointerException("Destination must not be null");
  387 |     }
  388 |     if (srcFile.exists() == false) {
  389 |       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
  390 |     }
  391 |     if (srcFile.isDirectory()) {
  392 |       throw new IOException("Source '" + srcFile + "' exists but is a directory");
  393 |     }
  394 |     if (srcFile.getCanonicalPath().equals(destFile.getCanonicalPath())) {
  395 |       throw new IOException("Source '" + srcFile + "' and destination '" + destFile + "' are the same");
  396 |     }
  397 |     File parentFile = destFile.getParentFile();
  398 |     if (parentFile != null) {
  399 |       if (!parentFile.mkdirs() && !parentFile.isDirectory()) {
  400 |         throw new IOException("Destination '" + parentFile + "' directory cannot be created");
  401 |       }
  402 |     }
  403 |     if (destFile.exists() && destFile.canWrite() == false) {
  404 |       throw new IOException("Destination '" + destFile + "' exists but is read-only");
  405 |     }
  406 |     doCopyFile(srcFile, destFile, preserveFileDate);
  407 |   }
  408 | 
  409 |   /**
  410 |    * Internal copy file method.
```


---
# 32. spark / fixed / c565525ede

## 89/100 flow_id c565525ede (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow c565525ede
key        : <spark.servlet.FilterTools: java.lang.String getRelativePath(javax.servlet.http.HttpServletRequest,java.lang.String)>@L55/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.servlet.FilterTools: java.lang.String getRelativePath(javax.servlet.http.HttpServletRequest,java.lang.String)>[39@L55] path#1 = invokestatic java.net.URLDecoder.decode(path#1, %c30)/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.servlet.FilterTools: java.lang.String getRelativePath(javax.servlet.http.HttpServletRequest,java.lang.String)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.servlet.FilterTools: java.lang.String getRelativePath(javax.servlet.http.HttpServletRequest,java.lang.String)>
file: spark/servlet/FilterTools.java
   31 |     }
   32 | 
   33 |     static String getRelativePath(HttpServletRequest request, String filterPath) {
   34 |         String path = request.getRequestURI();
   35 |         String contextPath = request.getContextPath();
   36 | 
   37 |         path = path.substring(contextPath.length());
   38 | 
   39 |         if (path.length() > 0) {
   40 |             path = path.substring(1);
   41 |         }
   42 | 
   43 |         if (!path.startsWith(filterPath) && filterPath.equals(path + SLASH)) {
   44 |             path += SLASH;
   45 |         }
   46 |         if (path.startsWith(filterPath)) {
   47 |             path = path.substring(filterPath.length());
   48 |         }
   49 | 
   50 |         if (!path.startsWith(SLASH)) {
   51 |             path = SLASH + path;
   52 |         }
   53 | 
   54 |         try {
   55 |             path = URLDecoder.decode(path, "UTF-8");
   56 |         } catch (UnsupportedEncodingException ex) {
   57 |             // this can't really ever happen
   58 |         }
   59 |         return path;
   60 |     }
   61 | 
   62 |     static String getFilterPath(FilterConfig config) {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 33. zt-zip / fixed / e2bf0cc685

## 44/97 flow_id e2bf0cc685 (priority 2)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow e2bf0cc685
key        : <org.zeroturnaround.zip.ZipUtil$11: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L2372/result => <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1223/1
source     : <org.zeroturnaround.zip.ZipUtil$11: void process(java.io.InputStream,java.util.zip.ZipEntry)>[1@L2372] entryName = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[19@L1223] invokespecial file.<init>(parentDirectory, %v22)/1
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$11: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$11: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 2369 |     final Set<String> names = new HashSet<String>();
 2370 |     iterate(is, new ZipEntryCallback() {
 2371 |       public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 2372 |         String entryName = zipEntry.getName();
 2373 |         if (names.add(entryName)) {
 2374 |           ZipEntryUtil.copyEntry(zipEntry, in, out);
 2375 |         }
 2376 |         else if (log.isDebugEnabled()) {
 2377 |           log.debug("Duplicate entry: {}", entryName);
 2378 |         }
 2379 |       }
 2380 |     });
 2381 |   }
 2382 | 

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1202 |     }
 1203 | 
 1204 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1205 |       String name = mapper.map(zipEntry.getName());
 1206 |       if (name != null) {
 1207 |         /**
 1208 |          * We assume that EVERY backslash will denote a directory
 1209 |          * separator. Also such broken archives don't have entries that
 1210 |          * are just directories. Everything is a file. See the example
 1211 |          *
 1212 |          * Archive: backSlashTest.zip
 1213 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1214 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1215 |          * No errors detected in compressed data of backSlashTest.zip.
 1216 |          */
 1217 |         if (name.indexOf('\\') != -1) {
 1218 |           File parentDirectory = outputDir;
 1219 |           String[] dirs = name.split("\\\\");
 1220 | 
 1221 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1222 |           for (int i = 0; i < dirs.length - 1; i++) {
 1223 |             File file = new File(parentDirectory, dirs[i]);
 1224 |             if (!file.exists()) {
 1225 |               FileUtils.forceMkdir(file);
 1226 |             }
 1227 |             parentDirectory = file;
 1228 |           }
 1229 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1230 | 
 1231 |           /* If we see the relative traversal string of ".." we need to make sure
 1232 |            * that the outputdir + name doesn't leave the outputdir. See
 1233 |            * DirectoryTraversalMaliciousTest for details.
 1234 |            */
 1235 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1236 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1237 |           }
 1238 | 
 1239 |           FileUtils.copy(in, destFile);
 1240 |         }
 1241 |         // it could be that there are just top level files that the unpacker is used for
 1242 |         else {
 1243 |           File destFile = new File(outputDir, name);
 1244 | 
 1245 |           /* If we see the relative traversal string of ".." we need to make sure
 1246 |            * that the outputdir + name doesn't leave the outputdir. See
 1247 |            * DirectoryTraversalMaliciousTest for details.
 1248 |            */
 1249 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1250 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1251 |           }
 1252 | 
 1253 |           FileUtils.copy(in, destFile);
 1254 |         }
 1255 |       }
 1256 |     }
 1257 |   }
 1258 | 
 1259 |   /**
```


---
# 34. zt-zip / buggy / 9d3ea03f69

## 103/115 flow_id 9d3ea03f69 (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 9d3ea03f69
key        : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1196/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>@L623/1
source     : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[4@L1196] %v9 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>[65@L623] invokespecial dstFile.<init>(destDir, %v52)/1
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtils.java
   51 |    * @throws java.io.IOException if file is not found or copying fails
   52 |    */
   53 |   public static void copy(InputStream in, File file) throws IOException {
   54 |     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
   55 |     try {
   56 |       IOUtils.copy(in, out);
   57 |     }
   58 |     finally {
   59 |       IOUtils.closeQuietly(out);
   60 |     }
   61 |   }
   62 | 
   63 |   /**
   64 |    * Find a non-existing file in the same directory using the same name as prefix.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void doCopyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean,java.util.List)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  603 |   private static void doCopyDirectory(File srcDir, File destDir, FileFilter filter,
  604 |       boolean preserveFileDate, List<String> exclusionList) throws IOException {
  605 |     // recurse
  606 |     File[] srcFiles = filter == null ? srcDir.listFiles() : srcDir.listFiles(filter);
  607 |     if (srcFiles == null) {  // null if abstract pathname does not denote a directory, or if an I/O error occurs
  608 |       throw new IOException("Failed to list contents of " + srcDir);
  609 |     }
  610 |     if (destDir.exists()) {
  611 |       if (destDir.isDirectory() == false) {
  612 |         throw new IOException("Destination '" + destDir + "' exists but is not a directory");
  613 |       }
  614 |     } else {
  615 |       if (!destDir.mkdirs() && !destDir.isDirectory()) {
  616 |         throw new IOException("Destination '" + destDir + "' directory cannot be created");
  617 |       }
  618 |     }
  619 |     if (destDir.canWrite() == false) {
  620 |       throw new IOException("Destination '" + destDir + "' cannot be written to");
  621 |     }
  622 |     for (File srcFile : srcFiles) {
  623 |       File dstFile = new File(destDir, srcFile.getName());
  624 |       if (exclusionList == null || !exclusionList.contains(srcFile.getCanonicalPath())) {
  625 |         if (srcFile.isDirectory()) {
  626 |           doCopyDirectory(srcFile, dstFile, filter, preserveFileDate, exclusionList);
  627 |         } else {
  628 |           doCopyFile(srcFile, dstFile, preserveFileDate);
  629 |         }
  630 |       }
  631 |     }
  632 | 
  633 |     // Do this last, as the above has probably affected directory metadata
  634 |     if (preserveFileDate) {
  635 |       destDir.setLastModified(srcDir.lastModified());
  636 |     }
  637 |   }
  638 | 
  639 |   //-----------------------------------------------------------------------
  640 |   /**
```


---
# 35. spark / buggy / ab7da7fe6f

## 111/113 flow_id ab7da7fe6f (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow ab7da7fe6f
key        : <org.eclipse.jetty.server.session.HashSessionManager: org.eclipse.jetty.server.session.HashedSession restoreSession(java.io.InputStream,org.eclipse.jetty.server.session.HashedSession)>@L644/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L222/0
source     : <org.eclipse.jetty.server.session.HashSessionManager: org.eclipse.jetty.server.session.HashedSession restoreSession(java.io.InputStream,org.eclipse.jetty.server.session.HashedSession)>[3@L644] clusterId = invokevirtual di.readUTF()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[25@L222] invokespecial %v19.<init>(%v20)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v2 run2, v3 run0, v3 run1, v3 run2, v3-noV2 run0, v3-noV2 run1, v3-noV2 run2, v3-noV3 run0, v3-noV3 run1, v3-noV3 run2, v3-noval run0, v3-noval run1, v3-noval run2, v4 run0, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.utils.ResourceUtils: java.io.File getFile(java.lang.String)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.utils.ResourceUtils: java.io.File getFile(java.lang.String)>
file: spark/utils/ResourceUtils.java
  161 |      *                               a file in the file system
  162 |      */
  163 |     public static File getFile(String resourceLocation) throws FileNotFoundException {
  164 |         Assert.notNull(resourceLocation, "Resource location must not be null");
  165 |         if (resourceLocation.startsWith(CLASSPATH_URL_PREFIX)) {
  166 |             String path = resourceLocation.substring(CLASSPATH_URL_PREFIX.length());
  167 |             String description = "class path resource [" + path + "]";
  168 |             URL url = ClassUtils.getDefaultClassLoader().getResource(path);
  169 |             if (url == null) {
  170 |                 throw new FileNotFoundException(
  171 |                         description + " cannot be resolved to absolute file path " +
  172 |                                 "because it does not reside in the file system"
  173 |                 );
  174 |             }
  175 |             return getFile(url, description);
  176 |         }
  177 |         try {
  178 |             // try URL
  179 |             return getFile(new URL(resourceLocation));
  180 |         } catch (MalformedURLException ex) {
  181 |             // no URL -> treat as file path
  182 |             return new File(resourceLocation);
  183 |         }
  184 |     }
  185 | 

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL)>
file: spark/utils/ResourceUtils.java
  193 |      *                               a file in the file system
  194 |      */
  195 |     public static File getFile(URL resourceUrl) throws FileNotFoundException {
  196 |         return getFile(resourceUrl, "URL");
  197 |     }
  198 | 
  199 |     /**

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 36. spark / fixed / 3b74d0637a

## 33/100 flow_id 3b74d0637a (priority 1)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 3b74d0637a
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L54/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[20@L54] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 37. spark / buggy / dfe1fd2b8f

## 84/113 flow_id dfe1fd2b8f (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow dfe1fd2b8f
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L51/result => <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>@L139/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[18@L51] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>[4@L139] is = invokevirtual %v4.getResourceAsStream(%v5)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run2, v3-noV2 run0, v3-noV3 run2, v3-noval run0, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResource: java.io.InputStream getInputStream()>
file: spark/resource/ClassPathResource.java
  135 |     @Override
  136 |     public InputStream getInputStream() throws IOException {
  137 |         InputStream is;
  138 |         if (this.clazz != null) {
  139 |             is = this.clazz.getResourceAsStream(this.path);
  140 |         } else {
  141 |             is = this.classLoader.getResourceAsStream(this.path);
  142 |         }
  143 |         if (is == null) {
  144 |             throw new FileNotFoundException(getDescription() + " cannot be opened because it does not exist");
  145 |         }
  146 |         return is;
  147 |     }
  148 | 
  149 |     /**
```


---
# 38. spark / buggy / 5c166c6349

## 113/113 flow_id 5c166c6349 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 5c166c6349
key        : <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>@L68/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L222/0
source     : <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>[18@L68] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[25@L222] invokespecial %v19.<init>(%v20)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```

---
# 39. zt-zip / fixed / 9aa5f75442

## 29/97 flow_id 9aa5f75442 (priority 1)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 9aa5f75442
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1277/result => <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper,int)>@L1626/0
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1277] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper,int)>[22@L1626] invokespecial %v21.<init>(targetZip)/0
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File)>, <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,boolean)>, <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,int)>, <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper)>, <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper,int)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1277 |       String root = getRootName(zipEntry.getName());
 1278 |       if (rootDir == null) {
 1279 |         rootDir = root;
 1280 |       }
 1281 |       else if (!rootDir.equals(root)) {
 1282 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1283 |       }
 1284 | 
 1285 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1286 |       if (name != null) {
 1287 |         File file = new File(outputDir, name);
 1288 | 
 1289 |         /* If we see the relative traversal string of ".." we need to make sure
 1290 |          * that the outputdir + name doesn't leave the outputdir. See
 1291 |          * DirectoryTraversalMaliciousTest for details.
 1292 |          */
 1293 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1294 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1295 |         }
 1296 | 
 1297 |         if (zipEntry.isDirectory()) {
 1298 |           FileUtils.forceMkdir(file);
 1299 |         }
 1300 |         else {
 1301 |           FileUtils.forceMkdir(file.getParentFile());
 1302 | 
 1303 |           if (log.isDebugEnabled() && file.exists()) {
 1304 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1305 |           }
 1306 | 
 1307 |           FileUtils.copy(in, file);
 1308 |         }
 1309 |       }
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());

### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/ZipUtil.java
 1399 |    *          ZIP file that will be created or overwritten.
 1400 |    */
 1401 |   public static void pack(File rootDir, File zip) {
 1402 |     pack(rootDir, zip, DEFAULT_COMPRESSION_LEVEL);
 1403 |   }
 1404 | 
 1405 |   /**
 1406 |    * Compresses the given directory and all its sub-directories into a ZIP file.

### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/ZipUtil.java
 1433 |    *          true if the resulted archive should have the top directory entry
 1434 |    */
 1435 |   public static void pack(final File sourceDir, final File targetZipFile, final boolean preserveRoot) {
 1436 |     if (preserveRoot) {
 1437 |       final String parentName = sourceDir.getName();
 1438 |       pack(sourceDir, targetZipFile, new NameMapper() {
 1439 |         public String map(String name) {
 1440 |           return parentName + PATH_SEPARATOR + name;
 1441 |         }
 1442 |       });
 1443 |     }
 1444 |     else {
 1445 |       pack(sourceDir, targetZipFile);
 1446 |     }
 1447 |   }
 1448 | 
 1449 |   /**
 1450 |    * Compresses the given file into a ZIP file.

### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,int)>
file: org/zeroturnaround/zip/ZipUtil.java
 1416 |    *          compression level
 1417 |    */
 1418 |   public static void pack(File rootDir, File zip, int compressionLevel) {
 1419 |     pack(rootDir, zip, IdentityNameMapper.INSTANCE, compressionLevel);
 1420 |   }
 1421 | 
 1422 |   /**
 1423 |    * Compresses the given directory and all its sub-directories into a ZIP file.

### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper)>
file: org/zeroturnaround/zip/ZipUtil.java
 1599 |    *          call-back for renaming the entries.
 1600 |    */
 1601 |   public static void pack(File sourceDir, File targetZip, NameMapper mapper) {
 1602 |     pack(sourceDir, targetZip, mapper, DEFAULT_COMPRESSION_LEVEL);
 1603 |   }
 1604 | 
 1605 |   /**
 1606 |    * Compresses the given directory and all its sub-directories into a ZIP file.

### <org.zeroturnaround.zip.ZipUtil: void pack(java.io.File,java.io.File,org.zeroturnaround.zip.NameMapper,int)>
file: org/zeroturnaround/zip/ZipUtil.java
 1617 |    *          compression level
 1618 |    */
 1619 |   public static void pack(File sourceDir, File targetZip, NameMapper mapper, int compressionLevel) {
 1620 |     log.debug("Compressing '{}' into '{}'.", sourceDir, targetZip);
 1621 |     if (!sourceDir.exists()) {
 1622 |       throw new ZipException("Given file '" + sourceDir + "' doesn't exist!");
 1623 |     }
 1624 |     ZipOutputStream out = null;
 1625 |     try {
 1626 |       out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(targetZip)));
 1627 |       out.setLevel(compressionLevel);
 1628 |       pack(sourceDir, out, mapper, "", true);
 1629 |     }
 1630 |     catch (IOException e) {
 1631 |       throw ZipExceptionUtil.rethrow(e);
 1632 |     }
 1633 |     finally {
 1634 |       IOUtils.closeQuietly(out);
 1635 |     }
 1636 |   }
 1637 | 
 1638 |   /**
 1639 |    * Compresses the given directory and all of its sub-directories into the passed in
```


---
# 40. zt-zip / fixed / 589b4f080d

## 34/97 flow_id 589b4f080d (priority 1)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 589b4f080d
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1277/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>@L584/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1277] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>[78@L584] invokespecial copiedFile.<init>(destDir, %v59)/1
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1277 |       String root = getRootName(zipEntry.getName());
 1278 |       if (rootDir == null) {
 1279 |         rootDir = root;
 1280 |       }
 1281 |       else if (!rootDir.equals(root)) {
 1282 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1283 |       }
 1284 | 
 1285 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1286 |       if (name != null) {
 1287 |         File file = new File(outputDir, name);
 1288 | 
 1289 |         /* If we see the relative traversal string of ".." we need to make sure
 1290 |          * that the outputdir + name doesn't leave the outputdir. See
 1291 |          * DirectoryTraversalMaliciousTest for details.
 1292 |          */
 1293 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1294 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1295 |         }
 1296 | 
 1297 |         if (zipEntry.isDirectory()) {
 1298 |           FileUtils.forceMkdir(file);
 1299 |         }
 1300 |         else {
 1301 |           FileUtils.forceMkdir(file.getParentFile());
 1302 | 
 1303 |           if (log.isDebugEnabled() && file.exists()) {
 1304 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1305 |           }
 1306 | 
 1307 |           FileUtils.copy(in, file);
 1308 |         }
 1309 |       }
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyDirectory(java.io.File,java.io.File,java.io.FileFilter,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  558 |    */
  559 |   public static void copyDirectory(File srcDir, File destDir,
  560 |       FileFilter filter, boolean preserveFileDate) throws IOException {
  561 |     if (srcDir == null) {
  562 |       throw new NullPointerException("Source must not be null");
  563 |     }
  564 |     if (destDir == null) {
  565 |       throw new NullPointerException("Destination must not be null");
  566 |     }
  567 |     if (srcDir.exists() == false) {
  568 |       throw new FileNotFoundException("Source '" + srcDir + "' does not exist");
  569 |     }
  570 |     if (srcDir.isDirectory() == false) {
  571 |       throw new IOException("Source '" + srcDir + "' exists but is not a directory");
  572 |     }
  573 |     if (srcDir.getCanonicalPath().equals(destDir.getCanonicalPath())) {
  574 |       throw new IOException("Source '" + srcDir + "' and destination '" + destDir + "' are the same");
  575 |     }
  576 | 
  577 |     // Cater for destination being directory within the source directory (see IO-141)
  578 |     List<String> exclusionList = null;
  579 |     if (destDir.getCanonicalPath().startsWith(srcDir.getCanonicalPath())) {
  580 |       File[] srcFiles = filter == null ? srcDir.listFiles() : srcDir.listFiles(filter);
  581 |       if (srcFiles != null && srcFiles.length > 0) {
  582 |         exclusionList = new ArrayList<String>(srcFiles.length);
  583 |         for (File srcFile : srcFiles) {
  584 |           File copiedFile = new File(destDir, srcFile.getName());
  585 |           exclusionList.add(copiedFile.getCanonicalPath());
  586 |         }
  587 |       }
  588 |     }
  589 |     doCopyDirectory(srcDir, destDir, filter, preserveFileDate, exclusionList);
  590 |   }
  591 | 
  592 |   /**
  593 |    * Internal copy directory method.
```


---
# 41. zt-zip / buggy / d15307a6a1

## 14/115 flow_id d15307a6a1 (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow d15307a6a1
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1250/result => <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1260/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[1@L1250] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[30@L1260] invokespecial file.<init>(%v28, name)/1
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v2 run2, v3 run0, v3 run1, v3 run2, v3-noV2 run0, v3-noV2 run1, v3-noV2 run2, v3-noV3 run0, v3-noV3 run1, v3-noV3 run2, v3-noval run0, v3-noval run1, v3-noval run2, v4 run0, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
 1278 |     }
 1279 | 
 1280 |     private String getRootName(final String name) {

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
```


---
# 42. spark / buggy / c87d7475f8

## 39/113 flow_id c87d7475f8 (priority 1)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow c87d7475f8
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L51/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[18@L51] pathInfo = invokeinterface request.getPathInfo()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 43. spark / fixed / f1e6570210

## 78/100 flow_id f1e6570210 (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow f1e6570210
key        : <org.eclipse.jetty.websocket.servlet.ServletUpgradeRequest: void <init>(javax.servlet.http.HttpServletRequest)>@L52/result => <spark.resource.JarResourceHandler: java.io.InputStream getResourceStream(java.lang.String)>@L81/0
source     : <org.eclipse.jetty.websocket.servlet.ServletUpgradeRequest: void <init>(javax.servlet.http.HttpServletRequest)>[3@L52] %v11 = invokeinterface httpRequest.getRequestURL()/result
sink       : <spark.resource.JarResourceHandler: java.io.InputStream getResourceStream(java.lang.String)>[6@L81] invokespecial %v28.<init>(path)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, iris-like run1, v1 run0, v1 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>, <spark.Service: spark.Service staticFileLocation(java.lang.String)>, <spark.Spark: void externalStaticFileLocation(java.lang.String)>, <spark.Spark: void staticFileLocation(java.lang.String)>, <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResourceStream(java.lang.String)>

## Code of the application methods on the route
### <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>
file: spark/Service.java
  247 |      * @return the object with external folder set
  248 |      */
  249 |     public synchronized Service externalStaticFileLocation(String externalFolder) {
  250 |         if (initialized && !isRunningFromServlet()) {
  251 |             throwBeforeRouteMappingException();
  252 |         }
  253 | 
  254 |         externalStaticFileFolder = externalFolder;
  255 | 
  256 |         if (!servletExternalStaticLocationSet) {
  257 |             staticFilesConfiguration.configureExternal(externalStaticFileFolder);
  258 |             servletExternalStaticLocationSet = true;
  259 |         } else {
  260 |             LOG.warn("External static file location has already been set");
  261 |         }
  262 |         return this;
  263 |     }
  264 | 
  265 |     /**

### <spark.Service: spark.Service staticFileLocation(java.lang.String)>
file: spark/Service.java
  224 |      * @return the object with folder set
  225 |      */
  226 |     public synchronized Service staticFileLocation(String folder) {
  227 |         if (initialized && !isRunningFromServlet()) {
  228 |             throwBeforeRouteMappingException();
  229 |         }
  230 | 
  231 |         staticFileFolder = folder;
  232 | 
  233 |         if (!servletStaticLocationSet) {
  234 |             staticFilesConfiguration.configure(staticFileFolder);
  235 |             servletStaticLocationSet = true;
  236 |         } else {
  237 |             LOG.warn("Static file location has already been set");
  238 |         }
  239 |         return this;
  240 |     }
  241 | 
  242 |     /**

### <spark.Spark: void externalStaticFileLocation(java.lang.String)>
file: spark/Spark.java
 1031 |      * @param externalFolder the external folder serving static files.
 1032 |      */
 1033 |     public static void externalStaticFileLocation(String externalFolder) {
 1034 |         getInstance().externalStaticFileLocation(externalFolder);
 1035 |     }
 1036 | 
 1037 |     /**
 1038 |      * Waits for the spark server to be initialized.

### <spark.Spark: void staticFileLocation(java.lang.String)>
file: spark/Spark.java
 1019 |      * @param folder the folder in classpath.
 1020 |      */
 1021 |     public static void staticFileLocation(String folder) {
 1022 |         getInstance().staticFileLocation(folder);
 1023 |     }
 1024 | 
 1025 |     /**
 1026 |      * Sets the external folder serving static files. <b>Observe: this method

### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResourceStream(java.lang.String)>
file: spark/resource/JarResourceHandler.java
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {
   80 |         if (path == null || !path.startsWith("/")) {
   81 |             throw new MalformedURLException(path);
   82 |         }
   83 | 
   84 |         InputStream resourceStream = null;
   85 | 
   86 |         try {
   87 |             path = UriPath.canonical(path);
   88 |             path = addPaths(baseResource, path);
   89 | 
   90 |             if (isDirectory(path)) {
   91 |                 if (welcomeFileConfigured()) {
   92 |                     path = addPaths(path, welcomeFile);
   93 |                     resourceStream = loadStream(path);
   94 |                 }
   95 |             } else {
   96 |                 resourceStream = loadStream(path);
   97 |             }
   98 | 
   99 |         } catch (Exception e) {
  100 |             if (LOG.isDebugEnabled()) {
  101 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
  102 |             }
  103 |         }
  104 | 
  105 |         return resourceStream;
  106 |     }
  107 | 
  108 |     private InputStream loadStream(String path) {
```


---
# 44. zt-zip / buggy / 02f3d795d7

## 27/115 flow_id 02f3d795d7 (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 02f3d795d7
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1250/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>@L1081/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[1@L1250] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>[18@L1081] invokespecial %v11.<init>(canonicalDir, %v12)/1
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v2 run2, v3 run0, v3 run1, v3 run2, v3-noV2 run0, v3-noV2 run1, v3-noV2 run2, v3-noV3 run0, v3-noV3 run1, v3-noV3 run2, v3-noval run0, v3-noval run1, v3-noval run2, v4 run0, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File)>, <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void deleteDirectory(java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());

### <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File)>
file: org/zeroturnaround/zip/ZipUtil.java
 1875 |    * @see #pack(File, File)
 1876 |    */
 1877 |   public static void unexplode(File dir) {
 1878 |     unexplode(dir, DEFAULT_COMPRESSION_LEVEL);
 1879 |   }
 1880 | 
 1881 |   /**
 1882 |    * Compresses a given directory in its own location.

### <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>
file: org/zeroturnaround/zip/ZipUtil.java
 1895 |   public static void unexplode(File dir, int compressionLevel) {
 1896 |     try {
 1897 |       // Find a new unique name is the same directory
 1898 |       File zip = FileUtils.getTempFileFor(dir);
 1899 | 
 1900 |       // Pack it
 1901 |       pack(dir, zip, compressionLevel);
 1902 | 
 1903 |       // Delete the directory
 1904 |       FileUtils.deleteDirectory(dir);
 1905 | 
 1906 |       // Rename the archive
 1907 |       FileUtils.moveFile(zip, dir);
 1908 |     }
 1909 |     catch (IOException e) {
 1910 |       throw ZipExceptionUtil.rethrow(e);
 1911 |     }
 1912 |   }
 1913 | 
 1914 |   /**
 1915 |    * Compresses the given entries into an output stream.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
 1067 |    * @since 2.0
 1068 |    */
 1069 |   public static boolean isSymlink(File file) throws IOException {
 1070 |     if (file == null) {
 1071 |       throw new NullPointerException("File must not be null");
 1072 |     }
 1073 |     if (FilenameUtils.isSystemWindows()) {
 1074 |       return false;
 1075 |     }
 1076 |     File fileInCanonicalDir = null;
 1077 |     if (file.getParent() == null) {
 1078 |       fileInCanonicalDir = file;
 1079 |     } else {
 1080 |       File canonicalDir = file.getParentFile().getCanonicalFile();
 1081 |       fileInCanonicalDir = new File(canonicalDir, file.getName());
 1082 |     }
 1083 | 
 1084 |     if (fileInCanonicalDir.getCanonicalFile().equals(fileInCanonicalDir.getAbsoluteFile())) {
 1085 |       return false;
 1086 |     } else {
 1087 |       return true;
 1088 |     }
 1089 |   }
 1090 | }

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void deleteDirectory(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  644 |    * @throws IOException in case deletion is unsuccessful
  645 |    */
  646 |   public static void deleteDirectory(File directory) throws IOException {
  647 |     if (!directory.exists()) {
  648 |       return;
  649 |     }
  650 | 
  651 |     if (!isSymlink(directory)) {
  652 |       cleanDirectory(directory);
  653 |     }
  654 | 
  655 |     if (!directory.delete()) {
  656 |       String message =
  657 |           "Unable to delete directory " + directory + ".";
  658 |       throw new IOException(message);
  659 |     }
  660 |   }
  661 | 
  662 |   /**
  663 |    * Deletes a file, never throwing an exception. If file is a directory, delete it and all sub-directories.
```


---
# 45. zt-zip / fixed / c5af9c7fc9

## 13/97 flow_id c5af9c7fc9 (priority 1)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow c5af9c7fc9
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1277/result => <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1152/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L1277] %v6 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[8@L1152] invokespecial file.<init>(%v11, name)/1
fixed methods on this flow (GT): Unwraper.process, Unpacker.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v2 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1202 |     }
 1203 | 
 1204 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1205 |       String name = mapper.map(zipEntry.getName());
 1206 |       if (name != null) {
 1207 |         /**
 1208 |          * We assume that EVERY backslash will denote a directory
 1209 |          * separator. Also such broken archives don't have entries that
 1210 |          * are just directories. Everything is a file. See the example
 1211 |          *
 1212 |          * Archive: backSlashTest.zip
 1213 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1214 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1215 |          * No errors detected in compressed data of backSlashTest.zip.
 1216 |          */
 1217 |         if (name.indexOf('\\') != -1) {
 1218 |           File parentDirectory = outputDir;
 1219 |           String[] dirs = name.split("\\\\");
 1220 | 
 1221 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1222 |           for (int i = 0; i < dirs.length - 1; i++) {
 1223 |             File file = new File(parentDirectory, dirs[i]);
 1224 |             if (!file.exists()) {
 1225 |               FileUtils.forceMkdir(file);
 1226 |             }
 1227 |             parentDirectory = file;
 1228 |           }
 1229 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1230 | 
 1231 |           /* If we see the relative traversal string of ".." we need to make sure
 1232 |            * that the outputdir + name doesn't leave the outputdir. See
 1233 |            * DirectoryTraversalMaliciousTest for details.
 1234 |            */
 1235 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1236 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1237 |           }
 1238 | 
 1239 |           FileUtils.copy(in, destFile);
 1240 |         }
 1241 |         // it could be that there are just top level files that the unpacker is used for
 1242 |         else {
 1243 |           File destFile = new File(outputDir, name);
 1244 | 
 1245 |           /* If we see the relative traversal string of ".." we need to make sure
 1246 |            * that the outputdir + name doesn't leave the outputdir. See
 1247 |            * DirectoryTraversalMaliciousTest for details.
 1248 |            */
 1249 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1250 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1251 |           }
 1252 | 
 1253 |           FileUtils.copy(in, destFile);
 1254 |         }
 1255 |       }
 1256 |     }
 1257 |   }
 1258 | 
 1259 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 | 
 1154 |         /* If we see the relative traversal string of ".." we need to make sure
 1155 |          * that the outputdir + name doesn't leave the outputdir. See
 1156 |          * DirectoryTraversalMaliciousTest for details.
 1157 |          */
 1158 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1159 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1160 |         }
 1161 | 
 1162 |         if (zipEntry.isDirectory()) {
 1163 |           FileUtils.forceMkdir(file);
 1164 |         }
 1165 |         else {
 1166 |           FileUtils.forceMkdir(file.getParentFile());
 1167 | 
 1168 |           if (log.isDebugEnabled() && file.exists()) {
 1169 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1170 |           }
 1171 | 
 1172 |           FileUtils.copy(in, file);
 1173 |         }
 1174 | 
 1175 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1176 |         if (permissions != null) {
 1177 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1178 |         }
 1179 |       }
 1180 |     }
 1181 |   }
 1182 | 
 1183 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>
file: org/zeroturnaround/zip/ZipUtil.java
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());
 1314 |     }
 1315 | 
 1316 |     private String getRootName(final String name) {

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1277 |       String root = getRootName(zipEntry.getName());
 1278 |       if (rootDir == null) {
 1279 |         rootDir = root;
 1280 |       }
 1281 |       else if (!rootDir.equals(root)) {
 1282 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1283 |       }
 1284 | 
 1285 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1286 |       if (name != null) {
 1287 |         File file = new File(outputDir, name);
 1288 | 
 1289 |         /* If we see the relative traversal string of ".." we need to make sure
 1290 |          * that the outputdir + name doesn't leave the outputdir. See
 1291 |          * DirectoryTraversalMaliciousTest for details.
 1292 |          */
 1293 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1294 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1295 |         }
 1296 | 
 1297 |         if (zipEntry.isDirectory()) {
 1298 |           FileUtils.forceMkdir(file);
 1299 |         }
 1300 |         else {
 1301 |           FileUtils.forceMkdir(file.getParentFile());
 1302 | 
 1303 |           if (log.isDebugEnabled() && file.exists()) {
 1304 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1305 |           }
 1306 | 
 1307 |           FileUtils.copy(in, file);
 1308 |         }
 1309 |       }
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());
```


---
# 46. spark / buggy / 72785618eb

## 68/113 flow_id 72785618eb (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 72785618eb
key        : <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>@L100/result => <org.slf4j.impl.SimpleLogger: java.io.PrintStream computeTargetStream(java.lang.String)>@L219/0
source     : <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>[10@L100] uri = invokeinterface httpRequest.getRequestURI()/result
sink       : <org.slf4j.impl.SimpleLogger: java.io.PrintStream computeTargetStream(java.lang.String)>[12@L219] invokespecial fos.<init>(logFile)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run2, v3 run2, v3-noV2 run2, v4 run0, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>

## Code of the application methods on the route
### <spark.http.matching.MatcherFilter: void doFilter(javax.servlet.ServletRequest,javax.servlet.ServletResponse,javax.servlet.FilterChain)>
file: spark/http/matching/MatcherFilter.java
   84 |                          ServletResponse servletResponse,
   85 |                          FilterChain chain) throws IOException, ServletException {
   86 | 
   87 |         HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
   88 |         HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;
   89 | 
   90 |         // handle static resources
   91 |         boolean consumedByStaticFile = staticFiles.consume(httpRequest, httpResponse);
   92 | 
   93 |         if (consumedByStaticFile) {
   94 |             return;
   95 |         }
   96 | 
   97 |         String method = getHttpMethodFrom(httpRequest);
   98 | 
   99 |         String httpMethodStr = method.toLowerCase();
  100 |         String uri = httpRequest.getRequestURI();
  101 |         String acceptType = httpRequest.getHeader(ACCEPT_TYPE_REQUEST_MIME_HEADER);
  102 | 
  103 |         Body body = Body.create();
  104 | 
  105 |         RequestWrapper requestWrapper = RequestWrapper.create();
  106 |         ResponseWrapper responseWrapper = ResponseWrapper.create();
  107 | 
  108 |         Response response = RequestResponseFactory.create(httpResponse);
  109 | 
  110 |         HttpMethod httpMethod = HttpMethod.get(httpMethodStr);
  111 | 
  112 |         RouteContext context = RouteContext.create()
  113 |                 .withMatcher(routeMatcher)
      | ... (lines omitted) ...
  137 |         }
  138 | 
  139 |         // If redirected and content is null set to empty string to not throw NotConsumedException
  140 |         if (body.notSet() && responseWrapper.isRedirected()) {
  141 |             body.set("");
  142 |         }
  143 | 
  144 |         if (body.notSet() && hasOtherHandlers) {
  145 |             if (servletRequest instanceof HttpRequestWrapper) {
  146 |                 ((HttpRequestWrapper) servletRequest).notConsumed(true);
  147 |                 return;
  148 |             }
  149 |         }
  150 | 
  151 |         if (body.notSet() && !externalContainer) {
  152 |             LOG.info("The requested route [" + uri + "] has not been mapped in Spark");
  153 |             httpResponse.setStatus(HttpServletResponse.SC_NOT_FOUND);
  154 |             body.set(String.format(NOT_FOUND));
  155 |         }
  156 | 
  157 |         if (body.isSet()) {
  158 |             body.serializeTo(httpResponse, serializerChain, httpRequest);
  159 | 
  160 |         } else if (chain != null) {
  161 |             chain.doFilter(httpRequest, httpResponse);
  162 |         }
  163 |     }
  164 | 
  165 |     private String getHttpMethodFrom(HttpServletRequest httpRequest) {
  166 |         String method = httpRequest.getHeader(HTTP_METHOD_OVERRIDE_HEADER);
```


---
# 47. spark / buggy / b0ff7d7476

## 78/113 flow_id b0ff7d7476 (priority 2)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow b0ff7d7476
key        : <org.eclipse.jetty.server.session.HashSessionIdManager: void addSession(javax.servlet.http.HttpSession)>@L121/result => <spark.resource.ClassPathResource: boolean exists()>@L120/0
source     : <org.eclipse.jetty.server.session.HashSessionIdManager: void addSession(javax.servlet.http.HttpSession)>[0@L121] %v7 = invokeinterface session.getId()/result
sink       : <spark.resource.ClassPathResource: boolean exists()>[6@L120] url = invokevirtual %v4.getResource(%v5)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, iris-like run2, v1 run1, v1 run2, v2 run2, v3 run2, v3-noV2 run2, v3-noV3 run2, v3-noval run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.ClassPathResource: boolean exists()>

## Code of the application methods on the route
### <spark.resource.ClassPathResource: boolean exists()>
file: spark/resource/ClassPathResource.java
  116 |     @Override
  117 |     public boolean exists() {
  118 |         URL url;
  119 |         if (this.clazz != null) {
  120 |             url = this.clazz.getResource(this.path);
  121 |         } else {
  122 |             url = this.classLoader.getResource(this.path);
  123 |         }
  124 |         return (url != null);
  125 |     }
  126 | 
  127 |     /**
```


---
# 48. zt-zip / buggy / 19eeaf5bac

## 58/115 flow_id 19eeaf5bac (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 19eeaf5bac
key        : <org.apache.log4j.Hierarchy: java.util.Enumeration getCurrentLoggers()>@L313/result => <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>@L61/0
source     : <org.apache.log4j.Hierarchy: java.util.Enumeration getCurrentLoggers()>[9@L313] o = invokeinterface elems.nextElement()/result
sink       : <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>[7@L61] invokespecial copy.<init>(%v5)/0
fixed methods on this flow (GT): -
reported by: iris-like run0, v1 run0, v2 run0, v3 run0, v3-noV2 run0, v3-noV3 run0, v3-noval run0, v4 run0

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipEntryUtil: java.util.zip.ZipEntry copy(java.util.zip.ZipEntry,java.lang.String)>
file: org/zeroturnaround/zip/ZipEntryUtil.java
   58 |    * @return copy of the original entry, but with the given name
   59 |    */
   60 |   static ZipEntry copy(ZipEntry original, String newName) {
   61 |     ZipEntry copy = new ZipEntry(newName == null ? original.getName() : newName);
   62 |     if (original.getCrc() != -1) {
   63 |       copy.setCrc(original.getCrc());
   64 |     }
   65 |     if (original.getMethod() != -1) {
   66 |       copy.setMethod(original.getMethod());
   67 |     }
   68 |     if (original.getSize() >= 0) {
   69 |       copy.setSize(original.getSize());
   70 |     }
   71 |     if (original.getExtra() != null) {
   72 |       copy.setExtra(original.getExtra());
   73 |     }
   74 | 
   75 |     copy.setComment(original.getComment());
   76 |     copy.setTime(original.getTime());
   77 |     return copy;
   78 |   }
   79 | 
   80 |   /**
```


---
# 49. spark / fixed / 87dd014ebd

## 1/100 flow_id 87dd014ebd (priority 1)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 87dd014ebd
key        : <org.eclipse.jetty.http.HttpParser: boolean parseHeaders(java.nio.ByteBuffer)>@L1002/result => <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>@L63/0
source     : <org.eclipse.jetty.http.HttpParser: boolean parseHeaders(java.nio.ByteBuffer)>[192@L1002] v = invokevirtual field.getValue()/result
sink       : <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>[6@L63] invokespecial %v36.<init>(path)/0
fixed methods on this flow (GT): ClassPathResourceHandler.getResource
reported by: iris-like run0, iris-like run1, v1 run0, v1 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>, <spark.Service: spark.Service staticFileLocation(java.lang.String)>, <spark.Spark: void externalStaticFileLocation(java.lang.String)>, <spark.Spark: void staticFileLocation(java.lang.String)>, <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>

## Code of the application methods on the route
### <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>
file: spark/Service.java
  247 |      * @return the object with external folder set
  248 |      */
  249 |     public synchronized Service externalStaticFileLocation(String externalFolder) {
  250 |         if (initialized && !isRunningFromServlet()) {
  251 |             throwBeforeRouteMappingException();
  252 |         }
  253 | 
  254 |         externalStaticFileFolder = externalFolder;
  255 | 
  256 |         if (!servletExternalStaticLocationSet) {
  257 |             staticFilesConfiguration.configureExternal(externalStaticFileFolder);
  258 |             servletExternalStaticLocationSet = true;
  259 |         } else {
  260 |             LOG.warn("External static file location has already been set");
  261 |         }
  262 |         return this;
  263 |     }
  264 | 
  265 |     /**

### <spark.Service: spark.Service staticFileLocation(java.lang.String)>
file: spark/Service.java
  224 |      * @return the object with folder set
  225 |      */
  226 |     public synchronized Service staticFileLocation(String folder) {
  227 |         if (initialized && !isRunningFromServlet()) {
  228 |             throwBeforeRouteMappingException();
  229 |         }
  230 | 
  231 |         staticFileFolder = folder;
  232 | 
  233 |         if (!servletStaticLocationSet) {
  234 |             staticFilesConfiguration.configure(staticFileFolder);
  235 |             servletStaticLocationSet = true;
  236 |         } else {
  237 |             LOG.warn("Static file location has already been set");
  238 |         }
  239 |         return this;
  240 |     }
  241 | 
  242 |     /**

### <spark.Spark: void externalStaticFileLocation(java.lang.String)>
file: spark/Spark.java
 1031 |      * @param externalFolder the external folder serving static files.
 1032 |      */
 1033 |     public static void externalStaticFileLocation(String externalFolder) {
 1034 |         getInstance().externalStaticFileLocation(externalFolder);
 1035 |     }
 1036 | 
 1037 |     /**
 1038 |      * Waits for the spark server to be initialized.

### <spark.Spark: void staticFileLocation(java.lang.String)>
file: spark/Spark.java
 1019 |      * @param folder the folder in classpath.
 1020 |      */
 1021 |     public static void staticFileLocation(String folder) {
 1022 |         getInstance().staticFileLocation(folder);
 1023 |     }
 1024 | 
 1025 |     /**
 1026 |      * Sets the external folder serving static files. <b>Observe: this method

### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   59 | 
   60 |     @Override
   61 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   62 |         if (path == null || !path.startsWith("/")) {
   63 |             throw new MalformedURLException(path);
   64 |         }
   65 | 
   66 |         try {
   67 |             path = UriPath.canonical(path);
   68 | 
   69 |             final String addedPath = addPaths(baseResource, path);
   70 | 
   71 |             ClassPathResource resource = new ClassPathResource(addedPath);
   72 | 
   73 |             if (resource.exists() && resource.getFile().isDirectory()) {
   74 |                 if (welcomeFile != null) {
   75 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   76 |                 } else {
   77 |                     //  No welcome file configured, serve nothing since it's a directory
   78 |                     resource = null;
   79 |                 }
   80 |             }
   81 | 
   82 |             if (resource != null && resource.exists()) {
   83 |                 DirectoryTraversal.protectAgainstInClassPath(resource.getPath());
   84 |                 return resource;
   85 |             } else {
   86 |                 return null;
   87 |             }
   88 | 
   89 |         } catch (DirectoryTraversal.DirectoryTraversalDetection directoryTraversalDetection) {
   90 |             throw directoryTraversalDetection;
   91 |         } catch (Exception e) {
   92 |             if (LOG.isDebugEnabled()) {
   93 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   94 |             }
   95 |         }
   96 |         return null;
   97 |     }
   98 | 
   99 | }
```


---
# 50. zt-zip / fixed / 74cc59b67f

## 77/97 flow_id 74cc59b67f (priority 2)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 74cc59b67f
key        : <org.zeroturnaround.zip.ZipUtil$19: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L2675/result => <org.zeroturnaround.zip.commons.FileUtils: java.io.File getTempFileFor(java.io.File)>@L75/1
source     : <org.zeroturnaround.zip.ZipUtil$19: void process(java.io.InputStream,java.util.zip.ZipEntry)>[2@L2675] %v5 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtils: java.io.File getTempFileFor(java.io.File)>[15@L75] invokespecial result.<init>(parent, %v16)/1
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1, v3 run0, v3 run1, v3-noV2 run0, v3-noV2 run1, v3-noV3 run0, v3-noV3 run1, v3-noval run0, v3-noval run1, v4 run0, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil$19: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtils: java.io.File getTempFileFor(java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil$19: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 2672 |         final Set<String> names = new HashSet<String>();
 2673 |         iterate(zip, new ZipEntryCallback() {
 2674 |           public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 2675 |             if (names.add(zipEntry.getName())) {
 2676 |               ZipEntrySource entry = (ZipEntrySource) entryByPath.remove(zipEntry.getName());
 2677 |               if (entry != null) {
 2678 |                 addEntry(entry, out);
 2679 |               }
 2680 |               else {
 2681 |                 ZipEntryUtil.copyEntry(zipEntry, in, out);
 2682 |               }
 2683 |             }
 2684 |             else if (log.isDebugEnabled()) {
 2685 |               log.debug("Duplicate entry: {}", zipEntry.getName());
 2686 |             }
 2687 |           }
 2688 |         });
 2689 | 
 2690 |         // Add new entries

### <org.zeroturnaround.zip.commons.FileUtils: java.io.File getTempFileFor(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtils.java
   67 |    * @return a non-existing file in the same directory using the same name as prefix.
   68 |    */
   69 |   public static File getTempFileFor(File file) {
   70 |     File parent = file.getParentFile();
   71 |     String name = file.getName();
   72 |     File result;
   73 |     int index = 0;
   74 |     do {
   75 |       result = new File(parent, name + "_" + index++);
   76 |     }
   77 |     while (result.exists());
   78 |     return result;
   79 |   }
   80 | }
```


---
# 51. zt-zip / buggy / 12c06dc687

## 86/115 flow_id 12c06dc687 (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 12c06dc687
key        : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>@L511/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>@L392/0
source     : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>[25@L511] %v24 = invokevirtual e.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>[35@L392] invokespecial %v20.<init>(%v27)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>
file: org/zeroturnaround/zip/ZipUtil.java
  490 |    * @see #iterate(File, ZipInfoCallback)
  491 |    */
  492 |   public static void iterate(File zip, ZipEntryCallback action, Charset charset) {
  493 |     ZipFile zf = null;
  494 |     try {
  495 |       if (charset == null) {
  496 |         zf = new ZipFile(zip);
  497 |       }
  498 |       else {
  499 |         zf = new ZipFile(zip, charset);
  500 |       }
  501 | 
  502 |       Enumeration<? extends ZipEntry> en = zf.entries();
  503 |       while (en.hasMoreElements()) {
  504 |         ZipEntry e = (ZipEntry) en.nextElement();
  505 | 
  506 |         InputStream is = zf.getInputStream(e);
  507 |         try {
  508 |           action.process(is, e);
  509 |         }
  510 |         catch (IOException ze) {
  511 |           throw new ZipException("Failed to process zip entry '" + e.getName() + "' with action " + action, ze);
  512 |         }
  513 |         catch (ZipBreakException ex) {
  514 |           break;
  515 |         }
  516 |         finally {
  517 |           IOUtils.closeQuietly(is);
  518 |         }
  519 |       }
  520 |     }
  521 |     catch (IOException e) {
  522 |       throw ZipExceptionUtil.rethrow(e);
  523 |     }
  524 |     finally {
  525 |       closeQuietly(zf);
  526 |     }
  527 |   }
  528 | 
  529 |   /**
  530 |    * Reads the given ZIP file and executes the given action for each given entry.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void copyFile(java.io.File,java.io.File,boolean)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  379 |    */
  380 |   public static void copyFile(File srcFile, File destFile,
  381 |       boolean preserveFileDate) throws IOException {
  382 |     if (srcFile == null) {
  383 |       throw new NullPointerException("Source must not be null");
  384 |     }
  385 |     if (destFile == null) {
  386 |       throw new NullPointerException("Destination must not be null");
  387 |     }
  388 |     if (srcFile.exists() == false) {
  389 |       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
  390 |     }
  391 |     if (srcFile.isDirectory()) {
  392 |       throw new IOException("Source '" + srcFile + "' exists but is a directory");
  393 |     }
  394 |     if (srcFile.getCanonicalPath().equals(destFile.getCanonicalPath())) {
  395 |       throw new IOException("Source '" + srcFile + "' and destination '" + destFile + "' are the same");
  396 |     }
  397 |     File parentFile = destFile.getParentFile();
  398 |     if (parentFile != null) {
  399 |       if (!parentFile.mkdirs() && !parentFile.isDirectory()) {
  400 |         throw new IOException("Destination '" + parentFile + "' directory cannot be created");
  401 |       }
  402 |     }
  403 |     if (destFile.exists() && destFile.canWrite() == false) {
  404 |       throw new IOException("Destination '" + destFile + "' exists but is read-only");
  405 |     }
  406 |     doCopyFile(srcFile, destFile, preserveFileDate);
  407 |   }
  408 | 
  409 |   /**
  410 |    * Internal copy file method.
```


---
# 52. spark / fixed / 9da6576286

## 83/100 flow_id 9da6576286 (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 9da6576286
key        : <org.eclipse.jetty.server.Server: void handleAsync(org.eclipse.jetty.server.HttpChannel)>@L562/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>@L258/0
source     : <org.eclipse.jetty.server.Server: void handleAsync(org.eclipse.jetty.server.HttpChannel)>[38@L562] %v38 = invokeinterface request.getMethod()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>[19@L258] invokespecial %v14.<init>(%v15)/0
fixed methods on this flow (GT): -
reported by: iris-like run2, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>

## Code of the application methods on the route
### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URI,java.lang.String)>
file: spark/utils/ResourceUtils.java
  248 |      *                               a file in the file system
  249 |      */
  250 |     public static File getFile(URI resourceUri, String description) throws FileNotFoundException {
  251 |         Assert.notNull(resourceUri, "Resource URI must not be null");
  252 |         if (!URL_PROTOCOL_FILE.equals(resourceUri.getScheme())) {
  253 |             throw new FileNotFoundException(
  254 |                     description + " cannot be resolved to absolute file path " +
  255 |                             "because it does not reside in the file system: " + resourceUri
  256 |             );
  257 |         }
  258 |         return new File(resourceUri.getSchemeSpecificPart());
  259 |     }
  260 | 
  261 |     /**
```


---
# 53. zt-zip / buggy / c4ac5ec6de

## 108/115 flow_id c4ac5ec6de (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow c4ac5ec6de
key        : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>@L511/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceDelete(java.io.File)>@L793/0
source     : <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>[25@L511] %v24 = invokevirtual e.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceDelete(java.io.File)>[25@L793] invokespecial %v18.<init>(message)/0
fixed methods on this flow (GT): -
reported by: iris-like run1, v1 run1, v2 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceDelete(java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void iterate(java.io.File,org.zeroturnaround.zip.ZipEntryCallback,java.nio.charset.Charset)>
file: org/zeroturnaround/zip/ZipUtil.java
  490 |    * @see #iterate(File, ZipInfoCallback)
  491 |    */
  492 |   public static void iterate(File zip, ZipEntryCallback action, Charset charset) {
  493 |     ZipFile zf = null;
  494 |     try {
  495 |       if (charset == null) {
  496 |         zf = new ZipFile(zip);
  497 |       }
  498 |       else {
  499 |         zf = new ZipFile(zip, charset);
  500 |       }
  501 | 
  502 |       Enumeration<? extends ZipEntry> en = zf.entries();
  503 |       while (en.hasMoreElements()) {
  504 |         ZipEntry e = (ZipEntry) en.nextElement();
  505 | 
  506 |         InputStream is = zf.getInputStream(e);
  507 |         try {
  508 |           action.process(is, e);
  509 |         }
  510 |         catch (IOException ze) {
  511 |           throw new ZipException("Failed to process zip entry '" + e.getName() + "' with action " + action, ze);
  512 |         }
  513 |         catch (ZipBreakException ex) {
  514 |           break;
  515 |         }
  516 |         finally {
  517 |           IOUtils.closeQuietly(is);
  518 |         }
  519 |       }
  520 |     }
  521 |     catch (IOException e) {
  522 |       throw ZipExceptionUtil.rethrow(e);
  523 |     }
  524 |     finally {
  525 |       closeQuietly(zf);
  526 |     }
  527 |   }
  528 | 
  529 |   /**
  530 |    * Reads the given ZIP file and executes the given action for each given entry.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void forceDelete(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  780 |    * @throws IOException in case deletion is unsuccessful
  781 |    */
  782 |   public static void forceDelete(File file) throws IOException {
  783 |     if (file.isDirectory()) {
  784 |       deleteDirectory(file);
  785 |     } else {
  786 |       boolean filePresent = file.exists();
  787 |       if (!file.delete()) {
  788 |         if (!filePresent){
  789 |           throw new FileNotFoundException("File does not exist: " + file);
  790 |         }
  791 |         String message =
  792 |             "Unable to delete file: " + file;
  793 |         throw new IOException(message);
  794 |       }
  795 |     }
  796 |   }
  797 | 
  798 |   /**
  799 |    * Schedules a file to be deleted when JVM exits.
```


---
# 54. zt-zip / fixed / 064f3842ce

## 85/97 flow_id 064f3842ce (priority 2)

```text
# zt-zip/fixed (CVE-2018-1002201, CWE-022) flow 064f3842ce
key        : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1205/result => <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>@L1081/1
source     : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[4@L1205] %v9 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>[18@L1081] invokespecial %v11.<init>(canonicalDir, %v12)/1
fixed methods on this flow (GT): -
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>, <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1202 |     }
 1203 | 
 1204 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1205 |       String name = mapper.map(zipEntry.getName());
 1206 |       if (name != null) {
 1207 |         /**
 1208 |          * We assume that EVERY backslash will denote a directory
 1209 |          * separator. Also such broken archives don't have entries that
 1210 |          * are just directories. Everything is a file. See the example
 1211 |          *
 1212 |          * Archive: backSlashTest.zip
 1213 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1214 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1215 |          * No errors detected in compressed data of backSlashTest.zip.
 1216 |          */
 1217 |         if (name.indexOf('\\') != -1) {
 1218 |           File parentDirectory = outputDir;
 1219 |           String[] dirs = name.split("\\\\");
 1220 | 
 1221 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1222 |           for (int i = 0; i < dirs.length - 1; i++) {
 1223 |             File file = new File(parentDirectory, dirs[i]);
 1224 |             if (!file.exists()) {
 1225 |               FileUtils.forceMkdir(file);
 1226 |             }
 1227 |             parentDirectory = file;
 1228 |           }
 1229 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1230 | 
 1231 |           /* If we see the relative traversal string of ".." we need to make sure
 1232 |            * that the outputdir + name doesn't leave the outputdir. See
 1233 |            * DirectoryTraversalMaliciousTest for details.
 1234 |            */
 1235 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1236 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1237 |           }
 1238 | 
 1239 |           FileUtils.copy(in, destFile);
 1240 |         }
 1241 |         // it could be that there are just top level files that the unpacker is used for
 1242 |         else {
 1243 |           File destFile = new File(outputDir, name);
 1244 | 
 1245 |           /* If we see the relative traversal string of ".." we need to make sure
 1246 |            * that the outputdir + name doesn't leave the outputdir. See
 1247 |            * DirectoryTraversalMaliciousTest for details.
 1248 |            */
 1249 |           if (name.indexOf("..") != -1 && !destFile.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1250 |             throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1251 |           }
 1252 | 
 1253 |           FileUtils.copy(in, destFile);
 1254 |         }
 1255 |       }
 1256 |     }
 1257 |   }
 1258 | 
 1259 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 | 
 1154 |         /* If we see the relative traversal string of ".." we need to make sure
 1155 |          * that the outputdir + name doesn't leave the outputdir. See
 1156 |          * DirectoryTraversalMaliciousTest for details.
 1157 |          */
 1158 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1159 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1160 |         }
 1161 | 
 1162 |         if (zipEntry.isDirectory()) {
 1163 |           FileUtils.forceMkdir(file);
 1164 |         }
 1165 |         else {
 1166 |           FileUtils.forceMkdir(file.getParentFile());
 1167 | 
 1168 |           if (log.isDebugEnabled() && file.exists()) {
 1169 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1170 |           }
 1171 | 
 1172 |           FileUtils.copy(in, file);
 1173 |         }
 1174 | 
 1175 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1176 |         if (permissions != null) {
 1177 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1178 |         }
 1179 |       }
 1180 |     }
 1181 |   }
 1182 | 
 1183 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1277 |       String root = getRootName(zipEntry.getName());
 1278 |       if (rootDir == null) {
 1279 |         rootDir = root;
 1280 |       }
 1281 |       else if (!rootDir.equals(root)) {
 1282 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1283 |       }
 1284 | 
 1285 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1286 |       if (name != null) {
 1287 |         File file = new File(outputDir, name);
 1288 | 
 1289 |         /* If we see the relative traversal string of ".." we need to make sure
 1290 |          * that the outputdir + name doesn't leave the outputdir. See
 1291 |          * DirectoryTraversalMaliciousTest for details.
 1292 |          */
 1293 |         if (name.indexOf("..") != -1 && !file.getCanonicalPath().startsWith(outputDir.getCanonicalPath())) {
 1294 |           throw new ZipException("The file "+name+" is trying to leave the target output directory of "+outputDir+". Ignoring this file.");
 1295 |         }
 1296 | 
 1297 |         if (zipEntry.isDirectory()) {
 1298 |           FileUtils.forceMkdir(file);
 1299 |         }
 1300 |         else {
 1301 |           FileUtils.forceMkdir(file.getParentFile());
 1302 | 
 1303 |           if (log.isDebugEnabled() && file.exists()) {
 1304 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1305 |           }
 1306 | 
 1307 |           FileUtils.copy(in, file);
 1308 |         }
 1309 |       }
 1310 |     }
 1311 | 
 1312 |     private String getUnrootedName(String root, String name) {
 1313 |       return name.substring(root.length());

### <org.zeroturnaround.zip.commons.FileUtils: void copy(java.io.InputStream,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtils.java
   51 |    * @throws java.io.IOException if file is not found or copying fails
   52 |    */
   53 |   public static void copy(InputStream in, File file) throws IOException {
   54 |     OutputStream out = new BufferedOutputStream(new FileOutputStream(file));
   55 |     try {
   56 |       IOUtils.copy(in, out);
   57 |     }
   58 |     finally {
   59 |       IOUtils.closeQuietly(out);
   60 |     }
   61 |   }
   62 | 
   63 |   /**
   64 |    * Find a non-existing file in the same directory using the same name as prefix.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean isSymlink(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
 1067 |    * @since 2.0
 1068 |    */
 1069 |   public static boolean isSymlink(File file) throws IOException {
 1070 |     if (file == null) {
 1071 |       throw new NullPointerException("File must not be null");
 1072 |     }
 1073 |     if (FilenameUtils.isSystemWindows()) {
 1074 |       return false;
 1075 |     }
 1076 |     File fileInCanonicalDir = null;
 1077 |     if (file.getParent() == null) {
 1078 |       fileInCanonicalDir = file;
 1079 |     } else {
 1080 |       File canonicalDir = file.getParentFile().getCanonicalFile();
 1081 |       fileInCanonicalDir = new File(canonicalDir, file.getName());
 1082 |     }
 1083 | 
 1084 |     if (fileInCanonicalDir.getCanonicalFile().equals(fileInCanonicalDir.getAbsoluteFile())) {
 1085 |       return false;
 1086 |     } else {
 1087 |       return true;
 1088 |     }
 1089 |   }
 1090 | }
```


---
# 55. zt-zip / buggy / 3d4c7875a7

## 78/115 flow_id 3d4c7875a7 (priority 2)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 3d4c7875a7
key        : DRIVER => <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean deleteQuietly(java.io.File)>@L689/base
source     : <nesy.NesyDriver: void main(java.lang.String[])>[172@L72] %v107 = invokestatic nesy.Taint.srcFile()/result
sink       : <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean deleteQuietly(java.io.File)>[8@L689] %v6 = invokevirtual file.delete()/base
fixed methods on this flow (GT): -
reported by: iris-like run0, v1 run0, v2 run0, v3 run0, v3-noV2 run0, v3-noV3 run0, v3-noval run0, v4 run0

## Route (taint flow graph)
1. <nesy.NesyDriver: void main(java.lang.String[])>[176@L75] %v110 = invokestatic nesy.Taint.srcFile()/result
2. VarNode{<nesy.NesyDriver: void main(java.lang.String[])>/%v110}
3. VarNode{<org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>/dir}
4. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveFile(java.io.File,java.io.File)>/destFile}
5. VarNode{<org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean deleteQuietly(java.io.File)>/file}
6. <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean deleteQuietly(java.io.File)>[8@L689] %v6 = invokevirtual file.delete()/base

## Code of the application methods on the route
### <org.zeroturnaround.zip.ZipUtil: void unexplode(java.io.File,int)>
file: org/zeroturnaround/zip/ZipUtil.java
 1895 |   public static void unexplode(File dir, int compressionLevel) {
 1896 |     try {
 1897 |       // Find a new unique name is the same directory
 1898 |       File zip = FileUtils.getTempFileFor(dir);
 1899 | 
 1900 |       // Pack it
 1901 |       pack(dir, zip, compressionLevel);
 1902 | 
 1903 |       // Delete the directory
 1904 |       FileUtils.deleteDirectory(dir);
 1905 | 
 1906 |       // Rename the archive
 1907 |       FileUtils.moveFile(zip, dir);
 1908 |     }
 1909 |     catch (IOException e) {
 1910 |       throw ZipExceptionUtil.rethrow(e);
 1911 |     }
 1912 |   }
 1913 | 
 1914 |   /**
 1915 |    * Compresses the given entries into an output stream.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: void moveFile(java.io.File,java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
 1023 |    * @since 1.4
 1024 |    */
 1025 |   public static void moveFile(File srcFile, File destFile) throws IOException {
 1026 |     if (srcFile == null) {
 1027 |       throw new NullPointerException("Source must not be null");
 1028 |     }
 1029 |     if (destFile == null) {
 1030 |       throw new NullPointerException("Destination must not be null");
 1031 |     }
 1032 |     if (!srcFile.exists()) {
 1033 |       throw new FileNotFoundException("Source '" + srcFile + "' does not exist");
 1034 |     }
 1035 |     if (srcFile.isDirectory()) {
 1036 |       throw new IOException("Source '" + srcFile + "' is a directory");
 1037 |     }
 1038 |     if (destFile.exists()) {
 1039 |       throw new FileExistsException("Destination '" + destFile + "' already exists");
 1040 |     }
 1041 |     if (destFile.isDirectory()) {
 1042 |       throw new IOException("Destination '" + destFile + "' is a directory");
 1043 |     }
 1044 |     boolean rename = srcFile.renameTo(destFile);
 1045 |     if (!rename) {
 1046 |       copyFile( srcFile, destFile );
 1047 |       if (!srcFile.delete()) {
 1048 |         FileUtils.deleteQuietly(destFile);
 1049 |         throw new IOException("Failed to delete original file '" + srcFile +
 1050 |             "' after copy to '" + destFile + "'");
 1051 |       }
 1052 |     }
 1053 |   }
 1054 | 
 1055 |   /**
 1056 |    * Determines whether the specified file is a Symbolic Link rather than an actual file.

### <org.zeroturnaround.zip.commons.FileUtilsV2_2: boolean deleteQuietly(java.io.File)>
file: org/zeroturnaround/zip/commons/FileUtilsV2_2.java
  675 |    * @since 1.4
  676 |    */
  677 |   public static boolean deleteQuietly(File file) {
  678 |     if (file == null) {
  679 |       return false;
  680 |     }
  681 |     try {
  682 |       if (file.isDirectory()) {
  683 |         cleanDirectory(file);
  684 |       }
  685 |     } catch (Exception ignored) {
  686 |     }
  687 | 
  688 |     try {
  689 |       return file.delete();
  690 |     } catch (Exception ignored) {
  691 |       return false;
  692 |     }
  693 |   }
  694 | 
```


---
# 56. spark / buggy / 3b74d0637a

## 40/113 flow_id 3b74d0637a (priority 1)

```text
# spark/buggy (CVE-2016-9177, CWE-022) flow 3b74d0637a
key        : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>@L54/result => <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>@L219/0
source     : <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>[20@L54] servletPath = invokeinterface request.getServletPath()/result
sink       : <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>[20@L219] invokespecial %v15.<init>(%v17)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run0, v2 run2, v3 run0, v3 run2, v3-noV2 run0, v3-noV2 run2, v3-noV3 run0, v3-noV3 run2, v3-noval run0, v3-noval run2, v4 run0, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>, <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>, <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>, <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>

## Code of the application methods on the route
### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.AbstractResourceHandler: spark.resource.AbstractFileResolvingResource getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/AbstractResourceHandler.java
   40 |     public AbstractFileResolvingResource getResource(HttpServletRequest request) throws MalformedURLException {
   41 |         String servletPath;
   42 |         String pathInfo;
   43 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   44 | 
   45 |         if (included) {
   46 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   47 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   48 | 
   49 |             if (servletPath == null && pathInfo == null) {
   50 |                 servletPath = request.getServletPath();
   51 |                 pathInfo = request.getPathInfo();
   52 |             }
   53 |         } else {
   54 |             servletPath = request.getServletPath();
   55 |             pathInfo = request.getPathInfo();
   56 |         }
   57 | 
   58 |         String pathInContext = addPaths(servletPath, pathInfo);
   59 |         return getResource(pathInContext);
   60 |     }
   61 | 
   62 |     /**

### <spark.resource.ClassPathResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ClassPathResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ClassPathResource resource = new ClassPathResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.getFile().isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ClassPathResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             return (resource != null && resource.exists()) ? resource : null;
   82 |         } catch (Exception e) {
   83 |             if (LOG.isDebugEnabled()) {
   84 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   85 |             }
   86 |         }
   87 |         return null;
   88 |     }
   89 | 
   90 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   57 | 
   58 |     @Override
   59 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   60 |         if (path == null || !path.startsWith("/")) {
   61 |             throw new MalformedURLException(path);
   62 |         }
   63 | 
   64 |         try {
   65 |             path = UriPath.canonical(path);
   66 | 
   67 |             final String addedPath = addPaths(baseResource, path);
   68 | 
   69 |             ExternalResource resource = new ExternalResource(addedPath);
   70 | 
   71 |             if (resource.exists() && resource.isDirectory()) {
   72 |                 if (welcomeFile != null) {
   73 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   74 |                 } else {
   75 |                     //  No welcome file configured, serve nothing since it's a directory
   76 |                     resource = null;
   77 |                 }
   78 |             }
   79 | 
   80 |             return (resource != null && resource.exists()) ? resource : null;
   81 |         } catch (Exception e) {
   82 |             if (LOG.isDebugEnabled()) {
   83 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   84 |             }
   85 |         }
   86 |         return null;
   87 |     }
   88 | 
   89 | }

### <spark.resource.JarResourceHandler: java.io.InputStream getResource(javax.servlet.http.HttpServletRequest)>
file: spark/resource/JarResourceHandler.java
   57 |         String servletPath;
   58 |         String pathInfo;
   59 | 
   60 |         boolean included = request.getAttribute(RequestDispatcher.INCLUDE_REQUEST_URI) != null;
   61 | 
   62 |         if (included) {
   63 |             servletPath = (String) request.getAttribute(RequestDispatcher.INCLUDE_SERVLET_PATH);
   64 |             pathInfo = (String) request.getAttribute(RequestDispatcher.INCLUDE_PATH_INFO);
   65 | 
   66 |             if (servletPath == null && pathInfo == null) {
   67 |                 servletPath = request.getServletPath();
   68 |                 pathInfo = request.getPathInfo();
   69 |             }
   70 |         } else {
   71 |             servletPath = request.getServletPath();
   72 |             pathInfo = request.getPathInfo();
   73 |         }
   74 | 
   75 |         String pathInContext = addPaths(servletPath, pathInfo);
   76 |         return getResourceStream(pathInContext);
   77 |     }
   78 | 
   79 |     private InputStream getResourceStream(String path) throws MalformedURLException {

### <spark.utils.ResourceUtils: java.io.File getFile(java.net.URL,java.lang.String)>
file: spark/utils/ResourceUtils.java
  208 |      *                               a file in the file system
  209 |      */
  210 |     public static File getFile(URL resourceUrl, String description) throws FileNotFoundException {
  211 |         Assert.notNull(resourceUrl, "Resource URL must not be null");
  212 |         if (!URL_PROTOCOL_FILE.equals(resourceUrl.getProtocol())) {
  213 |             throw new FileNotFoundException(
  214 |                     description + " cannot be resolved to absolute file path " +
  215 |                             "because it does not reside in the file system: " + resourceUrl
  216 |             );
  217 |         }
  218 |         try {
  219 |             return new File(toURI(resourceUrl).getSchemeSpecificPart());
  220 |         } catch (URISyntaxException ex) {
  221 |             // Fallback for URLs that are not valid URIs (should hardly ever happen).
  222 |             return new File(resourceUrl.getFile());
  223 |         }
  224 |     }
  225 | 
```


---
# 57. cron-utils / buggy / 7f847a860a

## 1/3 flow_id 7f847a860a (priority 1)

```text
# cron-utils/buggy (CVE-2021-41269, CWE-094) flow 7f847a860a
key        : DRIVER => <com.cronutils.validation.CronValidator: boolean isValid(java.lang.String,javax.validation.ConstraintValidatorContext)>@L33/0
source     : <nesy.NesyDriver: void main(java.lang.String[])>[8@L8] %v14 = invokestatic nesy.Taint.src()/result
sink       : <com.cronutils.validation.CronValidator: boolean isValid(java.lang.String,javax.validation.ConstraintValidatorContext)>[14@L33] %v14 = invokeinterface context.buildConstraintViolationWithTemplate(%v13)/0
fixed methods on this flow (GT): CronValidator.isValid
reported by: B2 run0, v1 run1, v1 run2, v2 run1, v2 run2, v4 run1, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <com.cronutils.validation.CronValidator: boolean isValid(java.lang.String,javax.validation.ConstraintValidatorContext)>

## Code of the application methods on the route
### <com.cronutils.validation.CronValidator: boolean isValid(java.lang.String,javax.validation.ConstraintValidatorContext)>
file: com/cronutils/validation/CronValidator.java
   19 | 
   20 |     @Override
   21 |     public boolean isValid(String value, ConstraintValidatorContext context) {
   22 |         if (value == null) {
   23 |             return true;
   24 |         }
   25 | 
   26 |         CronDefinition cronDefinition = CronDefinitionBuilder.instanceDefinitionFor(type);
   27 |         CronParser cronParser = new CronParser(cronDefinition);
   28 |         try {
   29 |             cronParser.parse(value).validate();
   30 |             return true;
   31 |         } catch (IllegalArgumentException e) {
   32 |             context.disableDefaultConstraintViolation();
   33 |             context.buildConstraintViolationWithTemplate(e.getMessage()).addConstraintViolation();
   34 |             return false;
   35 |         }
   36 |     }
   37 | }
```


---
# 58. zt-zip / buggy / 74f8b2218d

## 7/115 flow_id 74f8b2218d (priority 1)

```text
# zt-zip/buggy (CVE-2018-1002201, CWE-022) flow 74f8b2218d
key        : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1258/result => <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>@L1220/1
source     : <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>[24@L1258] %v24 = invokevirtual zipEntry.getName()/result
sink       : <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>[30@L1220] invokespecial destFile.<init>(parentDirectory, %v27)/1
fixed methods on this flow (GT): Unwraper.process
reported by: B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v2 run1, v3 run1, v3-noV2 run1, v3-noV3 run1, v3-noval run1, v4 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>, <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>

## Code of the application methods on the route
### <org.zeroturnaround.zip.IdentityNameMapper: java.lang.String map(java.lang.String)>
file: org/zeroturnaround/zip/IdentityNameMapper.java
   29 |   private IdentityNameMapper() {}
   30 |   
   31 |   public String map(String name) {
   32 |     return name;
   33 |   }
   34 | 
   35 | }

### <org.zeroturnaround.zip.ZipUtil$BackslashUnpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1193 |     }
 1194 | 
 1195 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1196 |       String name = mapper.map(zipEntry.getName());
 1197 |       if (name != null) {
 1198 |         /**
 1199 |          * We assume that EVERY backslash will denote a directory
 1200 |          * separator. Also such broken archives don't have entries that
 1201 |          * are just directories. Everything is a file. See the example
 1202 |          *
 1203 |          * Archive: backSlashTest.zip
 1204 |          * testing: testDirectory\testfileInTestDirectory.txt OK
 1205 |          * testing: testDirectory\testSubdirectory\testFileInTestSubdirectory.txt OK
 1206 |          * No errors detected in compressed data of backSlashTest.zip.
 1207 |          */
 1208 |         if (name.indexOf('\\') != -1) {
 1209 |           File parentDirectory = outputDir;
 1210 |           String[] dirs = name.split("\\\\");
 1211 | 
 1212 |           // lets create all the directories and the last entry is the file as EVERY entry is a file
 1213 |           for (int i = 0; i < dirs.length - 1; i++) {
 1214 |             File file = new File(parentDirectory, dirs[i]);
 1215 |             if (!file.exists()) {
 1216 |               FileUtils.forceMkdir(file);
 1217 |             }
 1218 |             parentDirectory = file;
 1219 |           }
 1220 |           File destFile = new File(parentDirectory, dirs[dirs.length - 1]);
 1221 |           FileUtils.copy(in, destFile);
 1222 |         }
 1223 |         // it could be that there are just top level files that the unpacker is used for
 1224 |         else {
 1225 |           File destFile = new File(outputDir, name);
 1226 |           FileUtils.copy(in, destFile);
 1227 |         }
 1228 |       }
 1229 |     }
 1230 |   }
 1231 | 
 1232 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unpacker: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1147 |     }
 1148 | 
 1149 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1150 |       String name = mapper.map(zipEntry.getName());
 1151 |       if (name != null) {
 1152 |         File file = new File(outputDir, name);
 1153 |         if (zipEntry.isDirectory()) {
 1154 |           FileUtils.forceMkdir(file);
 1155 |         }
 1156 |         else {
 1157 |           FileUtils.forceMkdir(file.getParentFile());
 1158 | 
 1159 |           if (log.isDebugEnabled() && file.exists()) {
 1160 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1161 |           }
 1162 | 
 1163 |           FileUtils.copy(in, file);
 1164 |         }
 1165 | 
 1166 |         ZTFilePermissions permissions = ZipEntryUtil.getZTFilePermissions(zipEntry);
 1167 |         if (permissions != null) {
 1168 |           ZTFilePermissionsUtil.getDefaultStategy().setPermissions(file, permissions);
 1169 |         }
 1170 |       }
 1171 |     }
 1172 |   }
 1173 | 
 1174 |   /**

### <org.zeroturnaround.zip.ZipUtil$Unwraper: java.lang.String getUnrootedName(java.lang.String,java.lang.String)>
file: org/zeroturnaround/zip/ZipUtil.java
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
 1278 |     }
 1279 | 
 1280 |     private String getRootName(final String name) {

### <org.zeroturnaround.zip.ZipUtil$Unwraper: void process(java.io.InputStream,java.util.zip.ZipEntry)>
file: org/zeroturnaround/zip/ZipUtil.java
 1247 |     }
 1248 | 
 1249 |     public void process(InputStream in, ZipEntry zipEntry) throws IOException {
 1250 |       String root = getRootName(zipEntry.getName());
 1251 |       if (rootDir == null) {
 1252 |         rootDir = root;
 1253 |       }
 1254 |       else if (!rootDir.equals(root)) {
 1255 |         throw new ZipException("Unwrapping with multiple roots is not supported, roots: " + rootDir + ", " + root);
 1256 |       }
 1257 | 
 1258 |       String name = mapper.map(getUnrootedName(root, zipEntry.getName()));
 1259 |       if (name != null) {
 1260 |         File file = new File(outputDir, name);
 1261 |         if (zipEntry.isDirectory()) {
 1262 |           FileUtils.forceMkdir(file);
 1263 |         }
 1264 |         else {
 1265 |           FileUtils.forceMkdir(file.getParentFile());
 1266 | 
 1267 |           if (log.isDebugEnabled() && file.exists()) {
 1268 |             log.debug("Overwriting file '{}'.", zipEntry.getName());
 1269 |           }
 1270 | 
 1271 |           FileUtils.copy(in, file);
 1272 |         }
 1273 |       }
 1274 |     }
 1275 | 
 1276 |     private String getUnrootedName(String root, String name) {
 1277 |       return name.substring(root.length());
```


---
# 59. spark / fixed / 42c1100513

## 9/100 flow_id 42c1100513 (priority 1)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 42c1100513
key        : <org.eclipse.jetty.server.Request: java.lang.String getServerName()>@L1367/result => <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>@L62/0
source     : <org.eclipse.jetty.server.Request: java.lang.String getServerName()>[2@L1367] name = invokevirtual %v3.getHost()/result
sink       : <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>[6@L62] invokespecial %v35.<init>(path)/0
fixed methods on this flow (GT): ExternalResourceHandler.getResource
reported by: iris-like run0, iris-like run1, v1 run0, v1 run1

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>, <spark.Service: spark.Service staticFileLocation(java.lang.String)>, <spark.Spark: void externalStaticFileLocation(java.lang.String)>, <spark.Spark: void staticFileLocation(java.lang.String)>, <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>, <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>

## Code of the application methods on the route
### <spark.Service: spark.Service externalStaticFileLocation(java.lang.String)>
file: spark/Service.java
  247 |      * @return the object with external folder set
  248 |      */
  249 |     public synchronized Service externalStaticFileLocation(String externalFolder) {
  250 |         if (initialized && !isRunningFromServlet()) {
  251 |             throwBeforeRouteMappingException();
  252 |         }
  253 | 
  254 |         externalStaticFileFolder = externalFolder;
  255 | 
  256 |         if (!servletExternalStaticLocationSet) {
  257 |             staticFilesConfiguration.configureExternal(externalStaticFileFolder);
  258 |             servletExternalStaticLocationSet = true;
  259 |         } else {
  260 |             LOG.warn("External static file location has already been set");
  261 |         }
  262 |         return this;
  263 |     }
  264 | 
  265 |     /**

### <spark.Service: spark.Service staticFileLocation(java.lang.String)>
file: spark/Service.java
  224 |      * @return the object with folder set
  225 |      */
  226 |     public synchronized Service staticFileLocation(String folder) {
  227 |         if (initialized && !isRunningFromServlet()) {
  228 |             throwBeforeRouteMappingException();
  229 |         }
  230 | 
  231 |         staticFileFolder = folder;
  232 | 
  233 |         if (!servletStaticLocationSet) {
  234 |             staticFilesConfiguration.configure(staticFileFolder);
  235 |             servletStaticLocationSet = true;
  236 |         } else {
  237 |             LOG.warn("Static file location has already been set");
  238 |         }
  239 |         return this;
  240 |     }
  241 | 
  242 |     /**

### <spark.Spark: void externalStaticFileLocation(java.lang.String)>
file: spark/Spark.java
 1031 |      * @param externalFolder the external folder serving static files.
 1032 |      */
 1033 |     public static void externalStaticFileLocation(String externalFolder) {
 1034 |         getInstance().externalStaticFileLocation(externalFolder);
 1035 |     }
 1036 | 
 1037 |     /**
 1038 |      * Waits for the spark server to be initialized.

### <spark.Spark: void staticFileLocation(java.lang.String)>
file: spark/Spark.java
 1019 |      * @param folder the folder in classpath.
 1020 |      */
 1021 |     public static void staticFileLocation(String folder) {
 1022 |         getInstance().staticFileLocation(folder);
 1023 |     }
 1024 | 
 1025 |     /**
 1026 |      * Sets the external folder serving static files. <b>Observe: this method

### <spark.resource.AbstractResourceHandler: java.lang.String addPaths(java.lang.String,java.lang.String)>
file: spark/resource/AbstractResourceHandler.java
   78 |      * @return Legally combined path segments.
   79 |      */
   80 |     public static String addPaths(String segment1, String segment2) {
   81 |         if (segment1 == null || segment1.length() == 0) {
   82 |             if (segment1 != null && segment2 == null) {
   83 |                 return segment1;
   84 |             }
   85 |             return segment2;
   86 |         }
   87 |         if (segment2 == null || segment2.length() == 0) {
   88 |             return segment1;
   89 |         }
   90 | 
   91 |         int split = segment1.indexOf(';');
   92 |         if (split < 0) {
   93 |             split = segment1.indexOf('?');
   94 |         }
   95 |         if (split == 0) {
   96 |             return segment2 + segment1;
   97 |         }
   98 |         if (split < 0) {
   99 |             split = segment1.length();
  100 |         }
  101 | 
  102 |         StringBuilder buf = new StringBuilder(segment1.length() + segment2.length() + 2);
  103 |         buf.append(segment1);
  104 | 
  105 |         if (buf.charAt(split - 1) == '/') {
  106 |             if (segment2.startsWith(SLASH)) {
  107 |                 buf.deleteCharAt(split - 1);
  108 |                 buf.insert(split - 1, segment2);
  109 |             } else {
  110 |                 buf.insert(split, segment2);
  111 |             }
  112 |         } else {
  113 |             if (segment2.startsWith(SLASH)) {
  114 |                 buf.insert(split, segment2);
  115 |             } else {
  116 |                 buf.insert(split, '/');
  117 |                 buf.insert(split + 1, segment2);
  118 |             }
  119 |         }
  120 | 
  121 |         return buf.toString();
  122 |     }
  123 | 
  124 | }

### <spark.resource.ExternalResourceHandler: spark.resource.AbstractFileResolvingResource getResource(java.lang.String)>
file: spark/resource/ExternalResourceHandler.java
   58 | 
   59 |     @Override
   60 |     protected AbstractFileResolvingResource getResource(String path) throws MalformedURLException {
   61 |         if (path == null || !path.startsWith("/")) {
   62 |             throw new MalformedURLException(path);
   63 |         }
   64 | 
   65 |         try {
   66 |             path = UriPath.canonical(path);
   67 | 
   68 |             final String addedPath = addPaths(baseResource, path);
   69 | 
   70 |             ExternalResource resource = new ExternalResource(addedPath);
   71 | 
   72 |             if (resource.exists() && resource.isDirectory()) {
   73 |                 if (welcomeFile != null) {
   74 |                     resource = new ExternalResource(addPaths(resource.getPath(), welcomeFile));
   75 |                 } else {
   76 |                     //  No welcome file configured, serve nothing since it's a directory
   77 |                     resource = null;
   78 |                 }
   79 |             }
   80 | 
   81 |             if (resource != null && resource.exists()) {
   82 |                 DirectoryTraversal.protectAgainstForExternal(resource.getPath());
   83 |                 return resource;
   84 |             } else {
   85 |                 return null;
   86 |             }
   87 | 
   88 |         } catch (DirectoryTraversal.DirectoryTraversalDetection directoryTraversalDetection) {
   89 |             throw directoryTraversalDetection;
   90 |         } catch (Exception e) {
   91 |             if (LOG.isDebugEnabled()) {
   92 |                 LOG.debug(e.getClass().getSimpleName() + " when trying to get resource. " + e.getMessage());
   93 |             }
   94 |         }
   95 |         return null;
   96 |     }
   97 | 
   98 | }
```


---
# 60. spark / fixed / 8efc8b3fbf

## 59/100 flow_id 8efc8b3fbf (priority 2)

```text
# spark/fixed (CVE-2016-9177, CWE-022) flow 8efc8b3fbf
key        : <org.eclipse.jetty.http.HttpFields: java.util.Set getFieldNamesCollection()>@L110/result => <org.slf4j.impl.SimpleLogger: java.io.PrintStream computeTargetStream(java.lang.String)>@L219/0
source     : <org.eclipse.jetty.http.HttpFields: java.util.Set getFieldNamesCollection()>[10@L110] %v12 = invokevirtual f.getName()/result
sink       : <org.slf4j.impl.SimpleLogger: java.io.PrintStream computeTargetStream(java.lang.String)>[12@L219] invokespecial fos.<init>(logFile)/0
fixed methods on this flow (GT): -
reported by: B1 run0, B2 run0, iris-like run0, iris-like run1, iris-like run2, v1 run0, v1 run1, v1 run2, v4 run2

## Route (taint flow graph)
(no complete application-code path in the taint flow graph; the flow passes through library code). Methods involved: <org.eclipse.jetty.http.HttpFields: java.util.Set getFieldNamesCollection()>, <org.slf4j.impl.SimpleLogger: java.io.PrintStream computeTargetStream(java.lang.String)>

## Code of the application methods on the route
(no application code available)
```

